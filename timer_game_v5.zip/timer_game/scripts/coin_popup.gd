class_name CoinPopup
extends Control
## INSERT COIN screen. Opens at 00:59 and 00:10 so more time can be added.
## Closes by itself when time is added or the session ends, or with CLOSE.

signal dismissed   # user pressed CLOSE

var _time: Label
var _hint: Label
var _test_box: Control


func _ready() -> void:
	visible = false
	theme = UIKit.theme()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP

	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.75)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(center)

	var box := UIKit.panel(UIKit.RED)
	box.custom_minimum_size = Vector2(640, 0)
	center.add_child(box)

	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	box.add_child(v)

	v.add_child(UIKit.label("INSERT COIN TO ADD TIME", 40, UIKit.RED, HORIZONTAL_ALIGNMENT_CENTER))
	_time = UIKit.label("", 76, UIKit.GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	v.add_child(_time)
	v.add_child(UIKit.label("Your time is almost up!", 24, UIKit.MUTED, HORIZONTAL_ALIGNMENT_CENTER))

	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 60)
	grid.add_theme_constant_override("v_separation", 6)
	var grid_center := CenterContainer.new()
	grid_center.add_child(grid)
	v.add_child(grid_center)
	for p in GameState.COIN_TABLE:
		grid.add_child(UIKit.label("₱%d" % p, 30, UIKit.GOLD))
		grid.add_child(UIKit.label("+ " + UIKit.long_duration(GameState.COIN_TABLE[p]), 26))

	_test_box = VBoxContainer.new()
	v.add_child(_test_box)
	_test_box.add_child(UIKit.label("TEST MODE - simulated payment (not a real coin)", 20, UIKit.GOLD, HORIZONTAL_ALIGNMENT_CENTER))
	var tf := HFlowContainer.new()
	tf.alignment = FlowContainer.ALIGNMENT_CENTER
	tf.add_theme_constant_override("h_separation", 10)
	tf.add_theme_constant_override("v_separation", 10)
	_test_box.add_child(tf)
	for p in GameState.COIN_TABLE:
		var b := UIKit.button("+ ₱%d" % p, 64, 24)
		b.custom_minimum_size.x = 150
		b.pressed.connect(CoinService.insert_test.bind(p))
		tf.add_child(b)

	_hint = UIKit.label("Insert your coin now.", 26, UIKit.NEON, HORIZONTAL_ALIGNMENT_CENTER)
	v.add_child(_hint)

	var close_btn := UIKit.button("CLOSE", 56, 22)
	close_btn.pressed.connect(_on_close_pressed)
	v.add_child(close_btn)

	GameState.tick.connect(_on_tick)
	GameState.time_added.connect(_on_time_added)
	GameState.session_expired.connect(_hide)
	GameState.session_reset.connect(_hide)


func open() -> void:
	if not GameState.active:
		return
	_test_box.visible = Settings.test_mode
	_hint.visible = not Settings.test_mode
	_on_tick(GameState.remaining)
	visible = true


func _hide() -> void:
	visible = false


func _on_close_pressed() -> void:
	visible = false
	dismissed.emit()


func _on_time_added(_pesos: int, _secs: int, _extended: bool) -> void:
	visible = false


func _on_tick(r: int) -> void:
	if visible:
		_time.text = UIKit.hms(r)
