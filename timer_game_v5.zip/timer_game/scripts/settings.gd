extends Node
## Persistent settings (autoload "Settings").

signal changed

const PATH := "user://settings.cfg"
const KEYS := ["volume", "muted", "voice_enabled", "test_mode", "overlay_enabled",
	"overlay_visible", "overlay_size", "overlay_alpha", "hw_enabled", "hw_secret",
	"pin_hash", "coin_enabled", "coin_popup"]

var volume := 0.8
var muted := false
var voice_enabled := true
var test_mode := true          # turn OFF in production (Admin > Test Mode)
var overlay_enabled := false   # only EFFECTIVE once Android grants the permission
var overlay_visible := true
var overlay_size := 1.0        # 0.5 .. 2.0
var overlay_alpha := 0.9       # 0.2 .. 1.0
var coin_popup := true         # INSERT COIN screen at 00:59 and 00:10
var hw_enabled := false
var hw_secret := ""
var pin_hash := ""
var coin_enabled := {1: true, 5: true, 10: true, 15: true, 20: true}


func _ready() -> void:
	var c := ConfigFile.new()
	if c.load(PATH) == OK:
		for k in KEYS:
			if c.has_section_key("s", k):
				set(k, c.get_value("s", k))
	if hw_secret == "":
		hw_secret = new_secret()
		save()


func update(key: String, value) -> void:
	set(key, value)
	save()
	changed.emit()


func save() -> void:
	var c := ConfigFile.new()
	for k in KEYS:
		c.set_value("s", k, get(k))
	c.save(PATH)


func new_secret() -> String:
	var r := RandomNumberGenerator.new()
	r.randomize()
	return "%06x" % r.randi_range(0, 0xFFFFFF)


func _hash(pin: String) -> String:
	return ("tg-salt-" + pin).sha256_text()


func check_pin(pin: String) -> bool:
	var want := pin_hash if pin_hash != "" else _hash("1234")   # default PIN: 1234
	return _hash(pin) == want


func set_pin(pin: String) -> void:
	update("pin_hash", _hash(pin))
