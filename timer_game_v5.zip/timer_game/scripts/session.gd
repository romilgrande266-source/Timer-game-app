extends Control
## SESSION SCREEN

var _seg: SevenSeg
var _remain: Label
var _banner: Label
var _paid: Label
var _warn: Label
var _float: Label
var _float_btn: Button
var _dot: Panel
var _test_panel: Control
var _banner_tween: Tween
var _t := 0.0


func _ready() -> void:
	theme = UIKit.theme()
	UIKit.add_background(self)
	_build()
	GameState.tick.connect(_on_tick)
	GameState.time_added.connect(_on_added)
	Settings.changed.connect(_refresh)
	OverlayBridge.status_changed.connect(_refresh)
	_on_tick(GameState.remaining)
	_refresh()
	if not GameState.active:
		Alerts.go.call_deferred(Alerts.HOME)


func _build() -> void:
	var scroll := ScrollContainer.new()
	scroll.set_anchors_preset(Control.PRESET_FULL_RECT)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(scroll)
	var margin := MarginContainer.new()
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin.size_flags_vertical = Control.SIZE_EXPAND_FILL
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	scroll.add_child(margin)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 14)
	margin.add_child(col)

	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 14)
	col.add_child(top)
	var ci := CoinIcon.new()
	ci.custom_minimum_size = Vector2(52, 52)
	top.add_child(ci)
	top.add_child(UIKit.label("TIMER GAME", 36, UIKit.NEON))
	var sp := Control.new()
	sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(sp)
	_dot = Panel.new()
	_dot.custom_minimum_size = Vector2(22, 22)
	var sb := StyleBoxFlat.new()
	sb.bg_color = UIKit.GREEN
	sb.set_corner_radius_all(11)
	_dot.add_theme_stylebox_override("panel", sb)
	var dotc := CenterContainer.new()
	dotc.add_child(_dot)
	top.add_child(dotc)
	top.add_child(UIKit.label("SESSION ACTIVE", 24, UIKit.GREEN))
	var adm := UIKit.button("ADMIN", 52, 20)
	adm.custom_minimum_size.x = 150
	adm.pressed.connect(func(): Alerts.go(Alerts.ADMIN))
	top.add_child(adm)

	_seg = SevenSeg.new()
	_seg.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_seg.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_seg.custom_minimum_size = Vector2(0, 220)
	col.add_child(_seg)

	_remain = UIKit.label("", 30, UIKit.MUTED, HORIZONTAL_ALIGNMENT_CENTER)
	col.add_child(_remain)
	_banner = UIKit.label("", 38, UIKit.GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	_banner.modulate.a = 0.0
	col.add_child(_banner)

	var flow := HFlowContainer.new()
	flow.alignment = FlowContainer.ALIGNMENT_CENTER
	flow.add_theme_constant_override("h_separation", 16)
	flow.add_theme_constant_override("v_separation", 16)
	col.add_child(flow)
	_paid = _info(flow, "PAYMENT")
	_warn = _info(flow, "WARNING SOUNDS")
	var fp := _info(flow, "FLOATING TIMER")
	_float = fp
	_float_btn = UIKit.button("", 48, 20)
	_float_btn.pressed.connect(func(): OverlayBridge.set_enabled(not Settings.overlay_enabled))
	(fp.get_parent() as VBoxContainer).add_child(_float_btn)

	_test_panel = UIKit.panel(UIKit.GOLD)
	col.add_child(_test_panel)
	var vt := VBoxContainer.new()
	_test_panel.add_child(vt)
	vt.add_child(UIKit.label("TEST MODE - ADD TIME (simulated payment, not a real coin)", 20, UIKit.GOLD))
	var tf := HFlowContainer.new()
	tf.add_theme_constant_override("h_separation", 10)
	tf.add_theme_constant_override("v_separation", 10)
	vt.add_child(tf)
	for p in GameState.COIN_TABLE:
		var b := UIKit.button("+ ₱%d" % p, 56, 22)
		b.custom_minimum_size.x = 150
		b.pressed.connect(CoinService.insert_test.bind(p))
		tf.add_child(b)
	col.add_child(UIKit.label("Insert coin to add more time", 22, UIKit.MUTED, HORIZONTAL_ALIGNMENT_CENTER))


func _info(parent: Control, title: String) -> Label:
	var p := UIKit.panel()
	p.custom_minimum_size.x = 380
	parent.add_child(p)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	p.add_child(v)
	v.add_child(UIKit.label(title, 22, UIKit.NEON))
	var l := UIKit.label("", 20)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(l)
	return l


func _on_tick(r: int) -> void:
	_seg.set_value(UIKit.hms(r))
	_remain.text = "%s remaining" % UIKit.long_duration(r)
	if r > 60:
		_warn.text = "Next: 01:00 beep, 00:59 voice,\n00:10 \"Please insert coin!\""
	elif r > 10:
		_warn.text = "01:00 warnings played.\nNext: 00:10 \"Please insert coin!\""
	else:
		_warn.text = "Final countdown - time's up at 00:00"
	if Settings.muted:
		_warn.text = "SOUND MUTED\n" + _warn.text


func _on_added(pesos: int, secs: int, _extended: bool) -> void:
	_banner.text = "+ %s ADDED  (₱%d)" % [UIKit.long_duration(secs).to_upper(), pesos]
	_banner.modulate.a = 1.0
	if _banner_tween:
		_banner_tween.kill()
	_banner_tween = create_tween()
	_banner_tween.tween_interval(3.0)
	_banner_tween.tween_property(_banner, "modulate:a", 0.0, 0.6)
	_refresh()


func _refresh() -> void:
	_paid.text = "Last payment: ₱%d  →  +%s\nTotal paid this session: ₱%d" % [
		GameState.last_paid, UIKit.long_duration(GameState.last_added), GameState.total_paid]
	_float.text = OverlayBridge.status_text()
	_float.add_theme_color_override("font_color", UIKit.GREEN if OverlayBridge.status_ok() else UIKit.GOLD)
	_float_btn.text = "DISABLE FLOATING TIMER" if Settings.overlay_enabled else "ENABLE FLOATING TIMER"
	_float_btn.visible = OverlayBridge.is_available()
	_test_panel.visible = Settings.test_mode
	_on_tick(GameState.remaining)


func _process(delta: float) -> void:
	_t += delta
	_dot.modulate.a = 0.5 + 0.5 * sin(_t * 3.0)
	var r := GameState.remaining
	var c := UIKit.NEON
	if r <= 10:
		c = UIKit.RED if int(_t * 3.0) % 2 == 0 else Color(0.45, 0.1, 0.15)
	elif r <= 60:
		c = UIKit.RED
	if c != _seg.on_color:
		_seg.set_color(c)
