extends Node
## Coin -> time conversion and the countdown (autoload "GameState").
## Uses wall-clock end time, so it stays exact across app switching / pausing.

signal time_added(pesos: int, seconds: int, extended: bool)
signal session_started
signal session_resumed
signal session_expired   # reached 00:00
signal session_reset     # admin reset
signal tick(remaining: int)
signal warning(point: int)   # 60 = 01:00 toast only, 59 = 00:59 warning sound, 10 = 00:10 warning sound

const COIN_TABLE := {1: 360, 5: 1200, 10: 3600, 15: 5400, 20: 7200}
const WARN_POINTS := [60, 59, 10]
const SAVE_PATH := "user://session.cfg"

var active := false
var end_unix := 0.0
var remaining := 0
var total_paid := 0
var last_paid := 0
var last_added := 0

# Used only by tests (detached instance, deterministic clock, no I/O).
var sandbox := false
var fake_now := -1.0

var _fired := {}


func _ready() -> void:
	_resume.call_deferred()


func _process(_delta: float) -> void:
	step()


func _now() -> float:
	return fake_now if fake_now >= 0.0 else Time.get_unix_time_from_system()


## Add a payment. Extends the running countdown; never resets it.
func add_payment(pesos: int, _source: String = "coin") -> bool:
	if not COIN_TABLE.has(pesos):
		return false
	if not sandbox and not Settings.coin_enabled.get(pesos, true):
		return false
	var secs: int = COIN_TABLE[pesos]
	var now := _now()
	var extended := active
	if active:
		end_unix += secs
	else:
		end_unix = now + secs
		active = true
		total_paid = 0
		_fired.clear()
	total_paid += pesos
	last_paid = pesos
	last_added = secs
	remaining = ceili(end_unix - now)
	for t in WARN_POINTS:          # re-arm warnings that are now in the future
		if remaining > t:
			_fired.erase(t)
	_save()
	time_added.emit(pesos, secs, extended)
	if not extended:
		session_started.emit()
	tick.emit(remaining)
	return true


func step() -> void:
	if not active:
		return
	var r := ceili(end_unix - _now())
	if r == remaining:
		return
	remaining = maxi(r, 0)
	tick.emit(remaining)
	if remaining <= 0:
		_finish(false)
		return
	var hit := -1
	for t in WARN_POINTS:          # descending, so the last hit is the most urgent
		if remaining <= t and not _fired.has(t):
			_fired[t] = true
			hit = t
	if hit != -1:
		warning.emit(hit)          # each point fires once, never every second


func reset_session() -> void:
	if active:
		_finish(true)


func _finish(was_reset: bool) -> void:
	active = false
	remaining = 0
	end_unix = 0.0
	_fired.clear()
	_save()
	if was_reset:
		session_reset.emit()
	else:
		session_expired.emit()


func _save() -> void:
	if sandbox:
		return
	var c := ConfigFile.new()
	c.set_value("s", "active", active)
	c.set_value("s", "end_unix", end_unix)
	c.set_value("s", "total_paid", total_paid)
	c.set_value("s", "last_paid", last_paid)
	c.set_value("s", "last_added", last_added)
	c.save(SAVE_PATH)


func _resume() -> void:
	var c := ConfigFile.new()
	if c.load(SAVE_PATH) != OK or not c.get_value("s", "active", false):
		return
	var end: float = c.get_value("s", "end_unix", 0.0)
	if end <= _now():
		_save()   # expired while the app was closed: stay idle
		return
	active = true
	end_unix = end
	total_paid = c.get_value("s", "total_paid", 0)
	last_paid = c.get_value("s", "last_paid", 0)
	last_added = c.get_value("s", "last_added", 0)
	remaining = ceili(end_unix - _now())
	for t in WARN_POINTS:
		if remaining <= t:
			_fired[t] = true
	session_resumed.emit()
