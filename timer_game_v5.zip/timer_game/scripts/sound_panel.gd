class_name SoundPanel
extends VBoxContainer
## Volume, mute, voice toggle and sound tests.

var _mute: CheckButton
var _voice: CheckButton
var _vol: HSlider


func _ready() -> void:
	add_theme_constant_override("separation", 12)
	add_child(UIKit.label("SOUND SETTINGS", 26, UIKit.NEON))
	var row := HBoxContainer.new()
	add_child(row)
	row.add_child(UIKit.label("Volume   "))
	_vol = HSlider.new()
	_vol.min_value = 0
	_vol.max_value = 100
	_vol.step = 1
	_vol.value = Settings.volume * 100.0
	_vol.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_vol.custom_minimum_size = Vector2(0, 44)
	_vol.value_changed.connect(func(v: float): Settings.update("volume", v / 100.0))
	row.add_child(_vol)
	_mute = CheckButton.new()
	_mute.text = "Mute all sound"
	_mute.custom_minimum_size = Vector2(0, 52)
	_mute.button_pressed = Settings.muted
	_mute.toggled.connect(func(on: bool): Settings.update("muted", on))
	add_child(_mute)
	_voice = CheckButton.new()
	_voice.text = "Voice announcements"
	_voice.custom_minimum_size = Vector2(0, 52)
	_voice.button_pressed = Settings.voice_enabled
	_voice.toggled.connect(func(on: bool): Settings.update("voice_enabled", on))
	add_child(_voice)
	var t := HBoxContainer.new()
	t.add_theme_constant_override("separation", 12)
	add_child(t)
	var b1 := UIKit.button("TEST BEEP", 52, 20)
	b1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b1.pressed.connect(func(): SoundManager.play("beep"))
	var b2 := UIKit.button("TEST VOICE", 52, 20)
	b2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b2.pressed.connect(func(): SoundManager.speak("Please insert coin!"))
	t.add_child(b1)
	t.add_child(b2)
