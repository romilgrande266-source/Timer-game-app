extends Node
# Headless: godot --headless --path . res://tests/SelfTest.tscn

func _ready() -> void:
	var r: Dictionary = SelfTest.run()
	print(r["log"])
	get_tree().quit(0 if r["ok"] else 1)
