// TIMER GAME - coin acceptor -> USB keyboard bridge.
// Board: any USB-HID capable Arduino (Leonardo / Pro Micro / ESP32-S3 / Pico with Keyboard lib).
// Wiring: multi-coin acceptor SIGNAL -> COIN_PIN (interrupt capable), GND shared.
// Program the acceptor so ONE PESO = ONE PULSE (P1=1, P5=5, P10=10, P15=15, P20=20 pulses).
// The board "types" a line:  TG,<pesos>,<secret>  +Enter   (and a heartbeat TG,HB,<secret> every 5 s)
// Set SECRET to the value shown in TIMER GAME > Admin > Coin System.
#include <Keyboard.h>

const int COIN_PIN = 3;
const char* SECRET = "CHANGE_ME";

volatile unsigned int pulses = 0;
volatile unsigned long lastPulse = 0;
unsigned long lastHb = 0;

void onPulse() {
  unsigned long n = millis();
  if (n - lastPulse > 20) { pulses++; lastPulse = n; }   // 20 ms debounce
}

void sendLine(const String& v) {
  Keyboard.print(String("TG,") + v + "," + SECRET);
  Keyboard.write(KEY_RETURN);
}

void setup() {
  pinMode(COIN_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(COIN_PIN), onPulse, FALLING);
  Keyboard.begin();
}

void loop() {
  noInterrupts();
  unsigned int p = pulses;
  unsigned long lp = lastPulse;
  interrupts();

  if (p > 0 && millis() - lp > 700) {       // coin finished: no pulses for 700 ms
    noInterrupts(); pulses = 0; interrupts();
    sendLine(String(p));
  } else if (p == 0 && millis() - lastHb > 5000) {
    lastHb = millis();
    sendLine("HB");
  }
}
