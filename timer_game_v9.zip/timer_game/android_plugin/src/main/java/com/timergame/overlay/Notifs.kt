package com.timergame.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.os.Build

object Notifs {
    const val CH_SESSION = "tg_session"
    const val CH_ALERTS = "tg_alerts"

    fun ensureChannels(c: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_SESSION, "Session timer", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERTS, "Timer alerts", NotificationManager.IMPORTANCE_HIGH))
    }

    fun launchIntent(c: Context): PendingIntent? {
        val i = c.packageManager.getLaunchIntentForPackage(c.packageName) ?: return null
        return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun post(c: Context, id: Int, title: String, text: String) {
        try {
            ensureChannels(c)
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, CH_ALERTS) else Notification.Builder(c)
            b.setSmallIcon(c.applicationInfo.icon)
                .setContentTitle(title).setContentText(text)
                .setAutoCancel(true).setContentIntent(launchIntent(c))
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, b.build())
        } catch (_: Exception) {
            // POST_NOTIFICATIONS not granted: ignore silently
        }
    }
}
