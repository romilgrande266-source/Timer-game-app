package com.timergame.overlay

import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.abs

/**
 * Foreground service that:
 *  - keeps counting down from the stored end time (independent of Godot),
 *  - shows the draggable floating timer over other apps (if permission granted),
 *  - plays the warning sounds / voice while the Godot app is in the background,
 *  - removes everything when the session expires.
 */
class OverlayService : Service() {

    companion object {
        @Volatile var appForeground = false   // set true/false by the plugin (onMainResume / onMainPause)
        @Volatile var instance: OverlayService? = null
        private const val ID_FG = 1
        private val CYAN = Color.rgb(34, 211, 255)
        private val RED = Color.rgb(255, 56, 96)
        private val GOLD = Color.rgb(255, 201, 51)
        private const val HINT = "Insert coin to add time"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var root: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var boxView: View? = null
    private var bubbleView: TextView? = null
    private var timeView: TextView? = null
    private var coinPanel: View? = null
    private var coinHint: TextView? = null
    // Coin buttons: opened by the 01:00 / 00:59 / 00:10 warnings. Kept here (not in the views) so the
    // panel survives every overlay rebuild and stays open after a coin is dropped; only X or the end
    // of the session closes it.
    private var coinsOpen = false
    private val resetHint = Runnable { coinHint?.text = HINT }
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val fired = HashSet<Int>()
    private var lastShown = Int.MIN_VALUE

    private val loop = object : Runnable {
        override fun run() { tick(); handler.postDelayed(this, 250) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        Notifs.ensureChannels(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) tts?.language = Locale.US
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Prefs.endMs(this) <= System.currentTimeMillis()) {
            startFg()   // startForegroundService() must be answered before we stop
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startFg()
        reload()
        handler.removeCallbacks(loop)
        handler.post(loop)
        return START_STICKY   // restart safely after the system kills us; state is in Prefs
    }

    override fun onDestroy() {
        handler.removeCallbacks(loop)
        removeOverlay()
        tts?.shutdown()
        instance = null
        super.onDestroy()
    }

    fun postReload() { handler.post { reload() } }

    private fun remainingSec(): Int =
        Math.ceil((Prefs.endMs(this) - System.currentTimeMillis()) / 1000.0).toInt()

    private fun startFg() {
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, Notifs.CH_SESSION)
                else Notification.Builder(this)
        b.setSmallIcon(applicationInfo.icon)
            .setContentTitle("TIMER GAME - session running")
            .setContentText("Time remaining is counting down")
            .setOngoing(true)
            .setContentIntent(Notifs.launchIntent(this))
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setWhen(Prefs.endMs(this))
        val n = b.build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID_FG, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID_FG, n)
        }
    }

    /** Called whenever time was added or settings changed. */
    private fun reload() {
        val rem = remainingSec()
        fired.removeAll { rem > it }   // re-arm warnings that are in the future again
        lastShown = Int.MIN_VALUE
        removeOverlay()
        if (Prefs.show(this) && !appForeground && Settings.canDrawOverlays(this)) createOverlay()
        tick()
    }

    private fun tick() {
        val rem = remainingSec()
        if (rem == lastShown) return
        lastShown = rem
        timeView?.text = fmt(maxOf(rem, 0))
        timeView?.setTextColor(if (rem <= 60) RED else CYAN)
        (bubbleView?.background as? GradientDrawable)?.setStroke(bubbleStroke(), if (rem <= 60) RED else CYAN)
        if (rem <= 0) { expire(); return }
        var hit = -1
        for (t in intArrayOf(60, 59, 10)) {
            if (rem <= t && fired.add(t)) hit = t
        }
        if (hit > 0) {
            openCoins()                      // show the coin buttons at 01:00 / 00:59 / 00:10
            if (!appForeground) warn(hit)
        }
    }

    // ---------------------------------------------------------------- coin buttons

    /** "1:360,5:1200" -> [(1, 360), (5, 1200)]  (pesos, seconds) */
    private fun coinList(): List<Pair<Int, Int>> =
        Prefs.coinSpec(this).split(",").mapNotNull {
            val a = it.split(":")
            val p = a.getOrNull(0)?.trim()?.toIntOrNull()
            val s = a.getOrNull(1)?.trim()?.toIntOrNull()
            if (p != null && s != null) Pair(p, s) else null
        }

    private fun openCoins() {
        if (coinList().isEmpty()) return     // test mode off: no touch buttons, real coins only
        coinsOpen = true
        coinPanel?.visibility = View.VISIBLE
        relayout()
    }

    private fun closeCoins() {
        coinsOpen = false
        coinPanel?.visibility = View.GONE
        relayout()
    }

    /** A coin tapped on the floating timer: extend the native countdown right now. */
    private fun insertCoin(pesos: Int, secs: Int) {
        val end = Prefs.endMs(this)
        if (end <= System.currentTimeMillis()) return          // session already over
        Prefs.setEndMs(this, end + secs * 1000L)
        Prefs.addPending(this, pesos)                          // Godot books it when the app is opened
        if (!Prefs.muted(this)) tone(ToneGenerator.TONE_PROP_ACK, 200)
        val rem = remainingSec()
        fired.removeAll { rem > it }                           // warnings become future events again
        lastShown = Int.MIN_VALUE
        startFg()                                              // notification clock follows the new end time
        tick()                                                 // timer text/colour; panel stays open
        coinHint?.text = "+₱$pesos  -  +${dur(secs)} added"
        handler.removeCallbacks(resetHint)
        handler.postDelayed(resetHint, 2500)
    }

    private fun dur(sec: Int): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        return when {
            h > 0 && m > 0 -> "${h}h ${m}m"
            h > 0 -> "${h}h"
            else -> "$m min"
        }
    }

    private fun dpx(v: Float, s: Float): Int = (v * resources.displayMetrics.density * s).toInt()

    /** Hint line + X, then one round gold button per coin value. */
    private fun buildCoinPanel(s: Float, coins: List<Pair<Int, Int>>): LinearLayout {
        val d = resources.displayMetrics.density
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dpx(8f, s), dpx(4f, s), dpx(4f, s), dpx(6f, s))
        panel.background = GradientDrawable().apply {
            setColor(Color.argb(215, 4, 8, 20))
            cornerRadius = 10 * d * s
            setStroke((1.5f * d).toInt().coerceAtLeast(2), GOLD)
        }

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val hint = TextView(this)
        hint.text = HINT
        hint.setTextColor(GOLD)
        hint.typeface = Typeface.DEFAULT_BOLD
        hint.textSize = 11f * s
        hint.maxLines = 1
        head.addView(hint, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val x = TextView(this)
        x.text = "✕"
        x.gravity = Gravity.CENTER
        x.setTextColor(Color.rgb(200, 215, 235))
        x.textSize = 13f * s
        x.setPadding(dpx(10f, s), dpx(2f, s), dpx(6f, s), dpx(2f, s))
        x.isClickable = true
        x.setOnClickListener { closeCoins() }
        head.addView(x)
        panel.addView(head)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        // Buttons shrink if the row would be wider than the screen (large size setting).
        val gap = dpx(4f, s)
        val avail = (resources.displayMetrics.widthPixels * 0.92f).toInt() - dpx(14f, s)
        val coinPx = minOf(dpx(42f, s), (avail - gap * coins.size) / maxOf(coins.size, 1))
            .coerceAtLeast(dpx(24f, s))
        for ((pesos, secs) in coins) {
            val b = TextView(this)
            b.text = "₱$pesos"
            b.gravity = Gravity.CENTER
            b.setTextColor(Color.rgb(90, 58, 0))
            b.typeface = Typeface.DEFAULT_BOLD
            b.textSize = 12f * s
            b.maxLines = 1
            b.includeFontPadding = false
            b.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(GOLD)
                setStroke((1.5f * d).toInt().coerceAtLeast(2), Color.rgb(255, 235, 150))
            }
            b.isClickable = true
            b.setOnClickListener { insertCoin(pesos, secs) }
            val lp = LinearLayout.LayoutParams(coinPx, coinPx)
            lp.leftMargin = gap / 2
            lp.rightMargin = gap / 2
            row.addView(b, lp)
        }
        panel.addView(row)
        coinHint = hint
        return panel
    }

    /** Window content changed size: apply it and make sure nothing hangs off the screen. */
    private fun relayout() {
        val r = root ?: return
        val p = params ?: return
        try { wm?.updateViewLayout(r, p) } catch (_: Exception) {}
        handler.postDelayed({ keepOnScreen() }, 80)
    }

    private fun warn(point: Int) {
        val muted = Prefs.muted(this)
        when (point) {
            60 -> {
                Notifs.post(this, 13, "One minute remaining", "Insert coin to add time")
            }
            59 -> if (!muted) beepSound()   // beep only, no voice
            10 -> {
                if (!muted) beepSound()   // same beep as 00:59, no voice
                Notifs.post(this, 14, "10 seconds remaining", "Please insert coin!")
            }
        }
    }

    private fun expire() {
        coinsOpen = false
        Prefs.setEndMs(this, 0L)
        handler.removeCallbacks(loop)
        // Time is up while the user is in another app: send the phone to its Home screen.
        // Done BEFORE removing the overlay window - a visible overlay is what lets Android
        // allow a start from the background.
        if (!appForeground) goToPhoneHome()
        removeOverlay()
        if (!appForeground) {
            if (!Prefs.muted(this)) tone(ToneGenerator.TONE_CDMA_ALERT_NETWORK_LITE, 1200)
            Notifs.post(this, 15, "Time expired", "Insert coin to start a new session")
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /** Same as pressing the Home button: the other app goes to the background. */
    private fun goToPhoneHome() {
        try {
            val home = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(home)
        } catch (_: Exception) {
            // Blocked by the system / phone brand: the "Time expired" notification still shows.
        }
    }

    /** Three short beeps (same pattern as the in-app "beep"). Used at 00:59 and 00:10. */
    private fun beepSound() {
        tone(ToneGenerator.TONE_PROP_BEEP, 120)
        handler.postDelayed({ tone(ToneGenerator.TONE_PROP_BEEP, 120) }, 300L)
        handler.postDelayed({ tone(ToneGenerator.TONE_PROP_BEEP, 120) }, 600L)
    }

    private fun tone(type: Int, ms: Int) {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, Prefs.volume(this).coerceIn(1, 100))
            tg.startTone(type, ms)
            handler.postDelayed({ tg.release() }, ms + 300L)
        } catch (_: Exception) {}
    }

    private fun speak(text: String) {
        if (!ttsReady) return
        val b = Bundle()
        b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Prefs.volume(this) / 100f)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, b, "tg")
    }

    private fun fmt(sec: Int) = String.format(Locale.US, "%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)

    private fun bubbleStroke(): Int = (3 * resources.displayMetrics.density).toInt().coerceAtLeast(3)

    /** Small box (coin + time + X). X shrinks it to a circle; tapping the circle expands it again. */
    private fun createOverlay() {
        val d = resources.displayMetrics.density
        val s = Prefs.sizePct(this) / 100f
        fun dp(v: Float) = (v * d * s).toInt()

        // column = [ box-or-circle ] over [ coin buttons ]; it is the one window added to the screen
        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        column.alpha = Prefs.alphaPct(this) / 100f
        val frame = FrameLayout(this)

        // ---- small box ----
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setPadding(dp(6f), dp(3f), dp(2f), dp(3f))
        box.background = GradientDrawable().apply {
            setColor(Color.argb(200, 4, 8, 20))
            cornerRadius = 10 * d * s
            setStroke((1.5f * d).toInt().coerceAtLeast(2), CYAN)
        }
        val coin = TextView(this)
        coin.text = "₱"
        coin.gravity = Gravity.CENTER
        coin.setTextColor(Color.rgb(90, 58, 0))
        coin.typeface = Typeface.DEFAULT_BOLD
        coin.textSize = 12f * s
        coin.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.rgb(255, 201, 51))
        }
        val cp = LinearLayout.LayoutParams(dp(22f), dp(22f))
        cp.rightMargin = dp(6f)
        box.addView(coin, cp)

        val tv = TextView(this)
        tv.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        tv.textSize = 17f * s
        tv.setTextColor(CYAN)
        tv.text = fmt(maxOf(remainingSec(), 0))
        box.addView(tv)

        val close = TextView(this)
        close.text = "✕"
        close.gravity = Gravity.CENTER
        close.setTextColor(Color.rgb(200, 215, 235))
        close.textSize = 14f * s
        close.setPadding(dp(10f), dp(4f), dp(8f), dp(4f))
        close.isClickable = true
        close.setOnClickListener { setCollapsed(true) }
        box.addView(close)

        // ---- circle ----
        val size = dp(44f)
        val bubble = TextView(this)
        bubble.text = "₱"
        bubble.gravity = Gravity.CENTER
        bubble.setTextColor(Color.rgb(90, 58, 0))
        bubble.typeface = Typeface.DEFAULT_BOLD
        bubble.textSize = 18f * s
        bubble.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.rgb(255, 201, 51))
            setStroke(bubbleStroke(), CYAN)
        }

        frame.addView(box)
        frame.addView(bubble, FrameLayout.LayoutParams(size, size))
        val collapsed = Prefs.collapsed(this)
        box.visibility = if (collapsed) View.GONE else View.VISIBLE
        bubble.visibility = if (collapsed) View.VISIBLE else View.GONE
        column.addView(frame, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        // ---- coin buttons (test mode only; shown from the 01:00 / 00:59 / 00:10 warnings) ----
        val coins = coinList()
        var panel: LinearLayout? = null
        if (coins.isNotEmpty()) {
            panel = buildCoinPanel(s, coins)
            panel.visibility = if (coinsOpen) View.VISIBLE else View.GONE
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(4f)
            column.addView(panel, lp)
        }

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = Prefs.x(this)
        p.y = Prefs.y(this)

        attachDrag(box, p, column, null)                       // drag the box
        attachDrag(bubble, p, column) { setCollapsed(false) }  // drag the circle, tap = expand
        if (panel != null) attachDrag(panel, p, column, null)  // drag by the panel background

        try {
            wm?.addView(column, p)
            params = p
            root = column
            boxView = box
            bubbleView = bubble
            timeView = tv
            coinPanel = panel
        } catch (_: Exception) {
            // Permission revoked between check and add: stay without overlay
        }
    }

    private fun setCollapsed(c: Boolean) {
        Prefs.setCollapsed(this, c)
        boxView?.visibility = if (c) View.GONE else View.VISIBLE
        bubbleView?.visibility = if (c) View.VISIBLE else View.GONE
        relayout()
    }

    /** After box <-> circle the window size changes: never let it hang off the screen. */
    private fun keepOnScreen() {
        val r = root ?: return
        val p = params ?: return
        val dm = resources.displayMetrics
        p.x = p.x.coerceIn(0, maxOf(0, dm.widthPixels - r.width))
        p.y = p.y.coerceIn(0, maxOf(0, dm.heightPixels - r.height))
        try { wm?.updateViewLayout(r, p) } catch (_: Exception) {}
    }

    /** Drag with finger; a touch that barely moves counts as a tap. */
    private fun attachDrag(v: View, p: WindowManager.LayoutParams, frame: View, onTap: (() -> Unit)?) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        v.setOnTouchListener { _: View, e: MotionEvent ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                    if (moved) {
                        p.x = sx + dx
                        p.y = sy + dy
                        try { wm?.updateViewLayout(frame, p) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) Prefs.savePos(this, p.x, p.y) else onTap?.invoke()
                }
            }
            true
        }
    }

    private fun removeOverlay() {
        try { root?.let { wm?.removeView(it) } } catch (_: Exception) {}
        root = null
        params = null
        boxView = null
        bubbleView = null
        timeView = null
        coinPanel = null
        coinHint = null
    }
}
