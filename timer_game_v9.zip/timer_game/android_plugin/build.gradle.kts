plugins {
    id("com.android.library") version "8.5.2"
    id("org.jetbrains.kotlin.android") version "2.1.0"
}

android {
    namespace = "com.timergame.overlay"
    compileSdk = 34
    defaultConfig { minSdk = 24 }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // CI extracts classes.jar from the Godot "AAR library" (same version as the editor) into ./libs
    //   unzip -p godot-lib.<ver>.template_release.aar classes.jar > libs/godot-classes.jar
    compileOnly(fileTree("libs") { include("*.jar") })
}
