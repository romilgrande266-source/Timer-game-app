extends Node
## Payment input (autoload "CoinService").
##  - TEST MODE buttons (simulated; clearly labelled, only when enabled by admin).
##  - Physical coin acceptor: a microcontroller (see hardware/coin_acceptor_hid.ino)
##    appears as a USB/Bluetooth keyboard and types "TG,<pesos>,<secret>" + Enter.
##    Works on Windows and Android (USB OTG). A heartbeat "TG,HB,<secret>" every 5 s
##    drives the connection status. Touchscreen buttons NEVER count as real coins.

signal coin_inserted(pesos: int, source: String)
signal hw_status_changed

var _buf := ""
var _last_key := 0.0
var _last_heartbeat := -1000.0


func _input(event: InputEvent) -> void:
	if not (event is InputEventKey) or not event.pressed or event.echo:
		return
	var now := Time.get_ticks_msec() / 1000.0
	if now - _last_key > 1.5:
		_buf = ""
	_last_key = now
	if event.keycode == KEY_ENTER or event.keycode == KEY_KP_ENTER:
		if _buf.begins_with("TG,"):
			_parse(_buf, now)
			get_viewport().set_input_as_handled()
		_buf = ""
		return
	if event.unicode > 0:
		_buf += char(event.unicode)
		if _buf.length() > 48:
			_buf = ""
		if _buf.begins_with("TG,") or "TG,".begins_with(_buf):
			get_viewport().set_input_as_handled()


func _parse(line: String, now: float) -> void:
	var p := line.split(",")
	if p.size() != 3 or not Settings.hw_enabled or p[2] != Settings.hw_secret:
		return
	if p[1] == "HB":
		_last_heartbeat = now
		hw_status_changed.emit()
	elif p[1].is_valid_int():
		_last_heartbeat = now
		insert(p[1].to_int(), "hardware")


func insert(pesos: int, source: String) -> bool:
	var ok := GameState.add_payment(pesos, source)
	if ok:
		coin_inserted.emit(pesos, source)
	else:
		Alerts.toast("Payment rejected: ₱%d" % pesos, true)
	return ok


func insert_test(pesos: int) -> bool:
	if not Settings.test_mode:
		return false
	return insert(pesos, "test")


func hw_connected() -> bool:
	return Settings.hw_enabled and Time.get_ticks_msec() / 1000.0 - _last_heartbeat < 15.0


func hw_status_text() -> String:
	if not Settings.hw_enabled:
		return "Disabled"
	return "Connected" if hw_connected() else "Waiting for acceptor..."
