class_name UIKit
extends RefCounted
## Shared cyber-cafe styling and small UI helpers.

const NEON := Color("22d3ff")
const NEON_DIM := Color("0b5d7a")
const GOLD := Color("ffc933")
const RED := Color("ff3860")
const GREEN := Color("2cff9a")
const MUTED := Color(0.6, 0.75, 0.9)

static var _theme: Theme


static func theme() -> Theme:
	if _theme:
		return _theme
	var t := Theme.new()
	var f := SystemFont.new()
	f.font_names = PackedStringArray(["Segoe UI", "Roboto", "Noto Sans", "Arial", "sans-serif"])
	t.default_font = f
	t.default_font_size = 22
	for state in ["normal", "hover", "pressed", "disabled"]:
		t.set_stylebox(state, "Button", _btn(state))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	t.set_color("font_color", "Button", Color.WHITE)
	t.set_color("font_hover_color", "Button", NEON)
	t.set_color("font_pressed_color", "Button", Color.WHITE)
	t.set_color("font_disabled_color", "Button", Color(0.5, 0.55, 0.65))
	_theme = t
	return t


static func _btn(state: String) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.set_corner_radius_all(12)
	sb.set_border_width_all(2)
	sb.set_content_margin_all(12)
	match state:
		"hover":
			sb.bg_color = Color("0f2150")
			sb.border_color = NEON
		"pressed":
			sb.bg_color = Color("123a73")
			sb.border_color = Color.WHITE
		"disabled":
			sb.bg_color = Color("0a0f1c")
			sb.border_color = Color("1b2538")
		_:
			sb.bg_color = Color("0a1530")
			sb.border_color = NEON_DIM
	return sb


static func panel_style(border: Color = NEON_DIM) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.04, 0.08, 0.17, 0.92)
	sb.border_color = border
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(14)
	sb.set_content_margin_all(18)
	return sb


static func panel(border: Color = NEON_DIM) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", panel_style(border))
	return p


static func label(text: String, font_size := 22, color := Color.WHITE, align := HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	l.horizontal_alignment = align
	return l


static func button(text: String, min_h := 64, font_size := 24) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, min_h)
	b.add_theme_font_size_override("font_size", font_size)
	b.focus_mode = Control.FOCUS_NONE
	return b


static func add_background(host: Control) -> void:
	var g := Gradient.new()
	g.set_color(0, Color("020409"))
	g.set_color(1, Color("0b1636"))
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(0, 1)
	gt.width = 4
	gt.height = 256
	var tr := TextureRect.new()
	tr.texture = gt
	tr.set_anchors_preset(Control.PRESET_FULL_RECT)
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	host.add_child(tr)
	var line := ColorRect.new()
	line.color = NEON
	line.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	line.offset_bottom = 3
	line.mouse_filter = Control.MOUSE_FILTER_IGNORE
	host.add_child(line)


@warning_ignore("integer_division")
static func hms(sec: int) -> String:
	sec = maxi(sec, 0)
	return "%02d:%02d:%02d" % [sec / 3600, (sec % 3600) / 60, sec % 60]


@warning_ignore("integer_division")
static func long_duration(sec: int) -> String:
	var h := sec / 3600
	var m := (sec % 3600) / 60
	var s := sec % 60
	var parts: Array[String] = []
	if h > 0:
		parts.append("%d hour%s" % [h, "" if h == 1 else "s"])
	if m > 0:
		parts.append("%d minute%s" % [m, "" if m == 1 else "s"])
	if s > 0 and h == 0:
		parts.append("%d second%s" % [s, "" if s == 1 else "s"])
	return " ".join(parts) if not parts.is_empty() else "0 seconds"


## PIN prompt. Calls on_ok only if the PIN is right.
static func ask_pin(host: Node, on_ok: Callable, title := "ADMIN PIN", on_cancel := Callable()) -> void:
	var dlg := ConfirmationDialog.new()
	dlg.title = title
	dlg.theme = theme()
	var le := LineEdit.new()
	le.secret = true
	le.placeholder_text = "Enter PIN"
	le.custom_minimum_size = Vector2(340, 56)
	le.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER
	dlg.add_child(le)
	dlg.register_text_enter(le)
	dlg.confirmed.connect(func():
		if Settings.check_pin(le.text):
			on_ok.call()
		else:
			Alerts.toast("Wrong PIN", true)
			if on_cancel.is_valid():
				on_cancel.call())
	dlg.canceled.connect(func():
		if on_cancel.is_valid():
			on_cancel.call())
	dlg.confirmed.connect(dlg.queue_free)
	dlg.canceled.connect(dlg.queue_free)
	host.add_child(dlg)
	dlg.popup_centered(Vector2i(460, 220))
	le.grab_focus()
