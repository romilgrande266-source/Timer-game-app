class_name CoinIcon
extends Control
## Gold peso coin icon drawn in code.


func _init() -> void:
	custom_minimum_size = Vector2(72, 72)


func _draw() -> void:
	var c := size / 2.0
	var r := minf(size.x, size.y) / 2.0 - 2.0
	draw_circle(c, r, Color("ffc933"))
	draw_arc(c, r, 0, TAU, 48, Color("ff9d00"), 4.0, true)
	draw_arc(c, r * 0.72, 0, TAU, 48, Color("b57600"), 2.0, true)
	var fs := int(r * 1.1)
	draw_string(get_theme_default_font(), Vector2(0, c.y + fs * 0.35), "₱",
		HORIZONTAL_ALIGNMENT_CENTER, size.x, fs, Color("5a3a00"))
