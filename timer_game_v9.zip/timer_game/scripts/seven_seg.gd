class_name SevenSeg
extends Control
## Seven-segment digital clock display ("HH:MM:SS"), drawn in code (no font needed).

const SEGS := {
	"0": "abcdef", "1": "bc", "2": "abdeg", "3": "abcdg", "4": "bcfg",
	"5": "acdfg", "6": "acdefg", "7": "abc", "8": "abcdefg", "9": "abcdfg",
}
var value_text := "00:00:00"
var on_color := Color("22d3ff")
var off_color := Color(0.13, 0.83, 1.0, 0.07)


func set_value(v: String) -> void:
	if v != value_text:
		value_text = v
		queue_redraw()


func set_color(c: Color) -> void:
	on_color = c
	off_color = Color(c.r, c.g, c.b, 0.07)
	queue_redraw()


func _draw() -> void:
	var digits := 0
	var colons := 0
	for ch in value_text:
		if ch == ":":
			colons += 1
		else:
			digits += 1
	var gap_f := 0.16
	var colon_f := 0.38
	var n := value_text.length()
	var units := digits + colons * colon_f + (n - 1) * gap_f
	var dw := minf(size.x / units, size.y / 1.8)
	var h := dw * 1.8
	var gap := dw * gap_f
	var total := digits * dw + colons * dw * colon_f + (n - 1) * gap
	var x := (size.x - total) / 2.0
	var y := (size.y - h) / 2.0
	var t := dw * 0.17
	for ch in value_text:
		if ch == ":":
			var cw := dw * colon_f
			var s := t * 0.9
			draw_rect(Rect2(x + cw / 2.0 - s / 2.0, y + h * 0.3 - s / 2.0, s, s), on_color)
			draw_rect(Rect2(x + cw / 2.0 - s / 2.0, y + h * 0.7 - s / 2.0, s, s), on_color)
			x += cw + gap
		else:
			_digit(ch, x, y, dw, h, t)
			x += dw + gap


func _digit(ch: String, x: float, y: float, w: float, h: float, t: float) -> void:
	var on: String = SEGS.get(ch, "")
	var g := t * 0.12
	var mid := y + h / 2.0
	var segs := {
		"a": _hseg(x + t / 2 + g, x + w - t / 2 - g, y + t / 2, t),
		"g": _hseg(x + t / 2 + g, x + w - t / 2 - g, mid, t),
		"d": _hseg(x + t / 2 + g, x + w - t / 2 - g, y + h - t / 2, t),
		"f": _vseg(x + t / 2, y + t / 2 + g, mid - g, t),
		"b": _vseg(x + w - t / 2, y + t / 2 + g, mid - g, t),
		"e": _vseg(x + t / 2, mid + g, y + h - t / 2 - g, t),
		"c": _vseg(x + w - t / 2, mid + g, y + h - t / 2 - g, t),
	}
	for k in segs:
		draw_colored_polygon(segs[k], on_color if on.contains(k) else off_color)


func _hseg(x0: float, x1: float, yc: float, t: float) -> PackedVector2Array:
	return PackedVector2Array([
		Vector2(x0, yc), Vector2(x0 + t / 2, yc - t / 2), Vector2(x1 - t / 2, yc - t / 2),
		Vector2(x1, yc), Vector2(x1 - t / 2, yc + t / 2), Vector2(x0 + t / 2, yc + t / 2)])


func _vseg(xc: float, y0: float, y1: float, t: float) -> PackedVector2Array:
	return PackedVector2Array([
		Vector2(xc, y0), Vector2(xc + t / 2, y0 + t / 2), Vector2(xc + t / 2, y1 - t / 2),
		Vector2(xc, y1), Vector2(xc - t / 2, y1 - t / 2), Vector2(xc - t / 2, y0 + t / 2)])
