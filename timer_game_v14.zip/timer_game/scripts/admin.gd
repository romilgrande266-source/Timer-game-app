extends Control
## ADMIN SETTINGS (PIN protected)

var _status: Label
var _hw: Label
var _secret: Label
var _result: Label
var _pin_edit: LineEdit
var _c_h: SpinBox
var _c_m: SpinBox
var _c_s: SpinBox
var _reset_btn: Button
var _acc := 0.0


func _ready() -> void:
	theme = UIKit.theme()
	UIKit.add_background(self)
	UIKit.ask_pin(self, _build, "ADMIN PIN REQUIRED", func(): Alerts.go(Alerts.HOME))


func _build() -> void:
	var scroll := ScrollContainer.new()
	scroll.set_anchors_preset(Control.PRESET_FULL_RECT)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(scroll)
	var margin := MarginContainer.new()
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 28)
	scroll.add_child(margin)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 18)
	margin.add_child(col)
	col.add_child(UIKit.label("ADMIN SETTINGS", 48, UIKit.NEON))

	var flow := HFlowContainer.new()
	flow.add_theme_constant_override("h_separation", 20)
	flow.add_theme_constant_override("v_separation", 20)
	col.add_child(flow)

	# Session status + reset
	var v := _card(flow, "SESSION STATUS")
	_status = UIKit.label("", 22)
	v.add_child(_status)
	_reset_btn = UIKit.button("RESET SESSION (PIN required)", 60, 22)
	_reset_btn.pressed.connect(func(): UIKit.ask_pin(self, _do_reset, "CONFIRM RESET - ENTER PIN"))
	v.add_child(_reset_btn)

	# Test mode
	v = _card(flow, "TEST MODE")
	var tm := CheckButton.new()
	tm.text = "Enable TEST MODE (simulated payments)"
	tm.custom_minimum_size = Vector2(0, 52)
	tm.button_pressed = Settings.test_mode
	tm.toggled.connect(func(on: bool): Settings.update("test_mode", on))
	v.add_child(tm)
	var note := UIKit.label("Turn OFF in production so only the real coin acceptor can add time.", 18, UIKit.MUTED)
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(note)

	# Sound + overlay
	v = _card(flow, "")
	v.add_child(SoundPanel.new())
	v = _card(flow, "")
	v.add_child(OverlayPanel.new())

	# Coin system
	v = _card(flow, "COIN SYSTEM")
	for p in GameState.COIN_TABLE:
		var cb := CheckButton.new()
		cb.text = "₱%d  →  %s" % [p, UIKit.long_duration(GameState.COIN_TABLE[p])]
		cb.custom_minimum_size = Vector2(0, 48)
		cb.button_pressed = Settings.coin_enabled.get(p, true)
		cb.toggled.connect(_on_coin_toggled.bind(p))
		v.add_child(cb)
	var hw := CheckButton.new()
	hw.text = "Hardware coin acceptor enabled"
	hw.custom_minimum_size = Vector2(0, 52)
	hw.button_pressed = Settings.hw_enabled
	hw.toggled.connect(func(on: bool): Settings.update("hw_enabled", on))
	v.add_child(hw)
	_hw = UIKit.label("", 22)
	v.add_child(_hw)
	_secret = UIKit.label("", 20, UIKit.MUTED)
	_secret.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(_secret)
	var regen := UIKit.button("GENERATE NEW ACCEPTOR SECRET", 52, 18)
	regen.pressed.connect(_regen_secret)
	v.add_child(regen)

	# Custom timer
	v = _card(flow, "CUSTOM TIMER")
	var cnote := UIKit.label("Add any amount of time without a coin. Starts a session if idle, otherwise adds to the running time. Not counted as a payment.", 18, UIKit.MUTED)
	cnote.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(cnote)
	var crow := HBoxContainer.new()
	crow.add_theme_constant_override("separation", 10)
	v.add_child(crow)
	_c_h = _spin(crow, "HRS", 99)
	_c_m = _spin(crow, "MIN", 59)
	_c_s = _spin(crow, "SEC", 59)
	_c_m.value = 5
	var cadd := UIKit.button("START / ADD CUSTOM TIME", 60, 22)
	cadd.pressed.connect(_add_custom)
	v.add_child(cadd)

	# Security
	v = _card(flow, "SECURITY")
	_pin_edit = LineEdit.new()
	_pin_edit.placeholder_text = "New PIN (4+ digits)"
	_pin_edit.secret = true
	_pin_edit.custom_minimum_size = Vector2(0, 56)
	_pin_edit.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER
	v.add_child(_pin_edit)
	var setpin := UIKit.button("CHANGE ADMIN PIN", 56, 20)
	setpin.pressed.connect(_set_pin)
	v.add_child(setpin)
	v.add_child(UIKit.label("Default PIN is 1234 - change it before deployment.", 18, UIKit.MUTED))

	# Diagnostics
	v = _card(flow, "DIAGNOSTICS")
	var st := UIKit.button("RUN LOGIC SELF-TEST", 56, 20)
	st.pressed.connect(_run_test)
	v.add_child(st)
	_result = UIKit.label("", 18)
	_result.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(_result)

	var bottom := HBoxContainer.new()
	bottom.add_theme_constant_override("separation", 16)
	col.add_child(bottom)
	var back := UIKit.button("BACK", 72, 26)
	back.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	back.pressed.connect(func(): Alerts.go(Alerts.HOME))
	bottom.add_child(back)
	var quit := UIKit.button("QUIT APP", 72, 26)
	quit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	quit.pressed.connect(func(): get_tree().quit())
	bottom.add_child(quit)
	_refresh_static()
	_refresh()


func _card(parent: Control, title: String) -> VBoxContainer:
	var p := UIKit.panel()
	p.custom_minimum_size.x = 560
	parent.add_child(p)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	p.add_child(v)
	if title != "":
		v.add_child(UIKit.label(title, 26, UIKit.NEON))
	return v


func _spin(parent: Control, suffix: String, max_v: int) -> SpinBox:
	var sb := SpinBox.new()
	sb.min_value = 0
	sb.max_value = max_v
	sb.step = 1
	sb.rounded = true
	sb.suffix = suffix
	sb.custom_minimum_size = Vector2(0, 60)
	sb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var le := sb.get_line_edit()
	le.add_theme_font_size_override("font_size", 24)
	le.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER
	parent.add_child(sb)
	return sb


func _add_custom() -> void:
	for sb in [_c_h, _c_m, _c_s]:
		sb.apply()   # commit a value that is still being typed
	var secs := int(_c_h.value) * 3600 + int(_c_m.value) * 60 + int(_c_s.value)
	if secs <= 0:
		Alerts.toast("Set a time greater than 00:00:00", true)
		return
	var added := GameState.add_custom_time(secs)
	if added <= 0:
		Alerts.toast("Timer is already at the 99:59:59 maximum", true)
		return
	if added < secs:
		Alerts.toast("Capped at 99:59:59 maximum", true)
	Alerts.go(Alerts.SESSION)


func _on_coin_toggled(on: bool, pesos: int) -> void:
	var d: Dictionary = Settings.coin_enabled.duplicate()
	d[pesos] = on
	Settings.update("coin_enabled", d)


func _regen_secret() -> void:
	Settings.update("hw_secret", Settings.new_secret())
	_refresh_static()


func _do_reset() -> void:
	GameState.reset_session()


func _set_pin() -> void:
	var p := _pin_edit.text
	if p.length() < 4 or not p.is_valid_int():
		Alerts.toast("PIN must be at least 4 digits", true)
		return
	Settings.set_pin(p)
	_pin_edit.text = ""
	Alerts.toast("PIN changed")


func _run_test() -> void:
	var r: Dictionary = SelfTest.run()
	_result.text = r["log"]
	_result.add_theme_color_override("font_color", UIKit.GREEN if r["ok"] else UIKit.RED)


func _refresh_static() -> void:
	_secret.text = "Acceptor secret: %s\nThe microcontroller types: TG,<pesos>,%s + Enter" % [Settings.hw_secret, Settings.hw_secret]


func _refresh() -> void:
	var s := "State: " + ("ACTIVE" if GameState.active else "IDLE")
	s += "\nRemaining: " + UIKit.hms(GameState.remaining)
	s += "\nTotal paid: ₱%d" % GameState.total_paid
	_status.text = s
	_reset_btn.disabled = not GameState.active
	_hw.text = "Acceptor status: " + CoinService.hw_status_text()


func _process(delta: float) -> void:
	_acc += delta
	if _acc >= 0.5 and _status != null:
		_acc = 0.0
		_refresh()
