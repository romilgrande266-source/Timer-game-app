extends Node
## Coin -> time conversion and the countdown (autoload "GameState").
## Uses wall-clock end time, so it stays exact across app switching / pausing.

signal time_added(pesos: int, seconds: int, extended: bool)
signal session_started
signal session_resumed
signal session_expired   # reached 00:00
signal session_reset     # admin reset
signal tick(remaining: int)
signal warning(point: int)   # 60 = 01:00 message only, 59 = 00:59 beep, 10 = 00:10 beep

const COIN_TABLE := {1: 360, 5: 1200, 10: 3600, 15: 5400, 20: 7200}
const WARN_POINTS := [60, 59, 10]
const MAX_SECONDS := 359999   # 99:59:59, the most the HH:MM:SS display can show
const SAVE_PATH := "user://session.cfg"

var active := false
var end_unix := 0.0
var remaining := 0
var total_paid := 0
var last_paid := 0
var last_added := 0

# Used only by tests (detached instance, deterministic clock, no I/O).
var sandbox := false
var fake_now := -1.0

var _fired := {}


func _ready() -> void:
	_resume.call_deferred()


func _process(_delta: float) -> void:
	step()


func _now() -> float:
	return fake_now if fake_now >= 0.0 else Time.get_unix_time_from_system()


## Add a payment. Extends the running countdown; never resets it.
func add_payment(pesos: int, _source: String = "coin") -> bool:
	if not COIN_TABLE.has(pesos):
		return false
	if not sandbox and not Settings.coin_enabled.get(pesos, true):
		return false
	_grant(pesos, COIN_TABLE[pesos])
	return true


## CUSTOM TIMER (admin): add any amount of time, not tied to a coin. Starts a session if idle,
## otherwise extends it (never resets). It is NOT a payment, so total_paid is unchanged.
## Returns the seconds actually added (0 = rejected). The countdown is capped at 99:59:59.
func add_custom_time(seconds: int) -> int:
	if seconds <= 0:
		return 0
	var room := MAX_SECONDS
	if active:
		room = MAX_SECONDS - ceili(end_unix - _now())
	var secs := mini(seconds, room)
	if secs <= 0:
		return 0
	_grant(0, secs)
	return secs


func _grant(pesos: int, secs: int) -> void:
	var now := _now()
	var extended := active
	if active:
		end_unix += secs
	else:
		end_unix = now + secs
		active = true
		total_paid = 0
		_fired.clear()
	total_paid += pesos
	last_paid = pesos
	last_added = secs
	remaining = ceili(end_unix - now)
	for t in WARN_POINTS:          # re-arm warnings that are now in the future
		if remaining > t:
			_fired.erase(t)
	_save()
	time_added.emit(pesos, secs, extended)
	if not extended:
		session_started.emit()
	tick.emit(remaining)


## Seconds left RIGHT NOW (remaining is only refreshed by step(), which does not run while the
## app is paused in the background).
func seconds_left() -> int:
	if not active:
		return 0
	return maxi(ceili(end_unix - _now()), 0)


## Coins tapped on the Android floating timer while the app was in the background.
## native_end = end time (unix seconds) the floating timer reached after those coins; it already
## contains all of them, so the session simply adopts it. Also revives a session that Godot had
## lost (app killed in the background) so a paid coin is never thrown away.
func apply_overlay_payments(pesos_list: Array, native_end: float) -> void:
	var paid := 0
	var last := 0
	for v in pesos_list:
		var p := int(v)
		if COIN_TABLE.has(p):
			paid += p
			last = p
	var now := _now()
	if paid == 0 or native_end <= now:
		return
	var was_active := active
	if not was_active:
		total_paid = 0
		_fired.clear()
	active = true
	end_unix = maxf(end_unix if was_active else 0.0, native_end)
	total_paid += paid
	last_paid = last
	last_added = COIN_TABLE[last]
	remaining = ceili(end_unix - now)
	for t in WARN_POINTS:
		if remaining > t:
			_fired.erase(t)
	_save()
	time_added.emit(last, last_added, was_active)
	if not was_active:
		session_started.emit()
	tick.emit(remaining)


func step() -> void:
	if not active:
		return
	var r := ceili(end_unix - _now())
	if r == remaining:
		return
	remaining = maxi(r, 0)
	tick.emit(remaining)
	if remaining <= 0:
		_finish(false)
		return
	var hit := -1
	for t in WARN_POINTS:          # descending, so the last hit is the most urgent
		if remaining <= t and not _fired.has(t):
			_fired[t] = true
			hit = t
	if hit != -1:
		warning.emit(hit)          # each point fires once, never every second


func reset_session() -> void:
	if active:
		_finish(true)


func _finish(was_reset: bool) -> void:
	active = false
	remaining = 0
	end_unix = 0.0
	_fired.clear()
	_save()
	if was_reset:
		session_reset.emit()
	else:
		session_expired.emit()


func _save() -> void:
	if sandbox:
		return
	var c := ConfigFile.new()
	c.set_value("s", "active", active)
	c.set_value("s", "end_unix", end_unix)
	c.set_value("s", "total_paid", total_paid)
	c.set_value("s", "last_paid", last_paid)
	c.set_value("s", "last_added", last_added)
	c.save(SAVE_PATH)


func _resume() -> void:
	var c := ConfigFile.new()
	if c.load(SAVE_PATH) != OK or not c.get_value("s", "active", false):
		return
	var end: float = c.get_value("s", "end_unix", 0.0)
	if end <= _now():
		_save()   # expired while the app was closed: stay idle
		return
	active = true
	end_unix = end
	total_paid = c.get_value("s", "total_paid", 0)
	last_paid = c.get_value("s", "last_paid", 0)
	last_added = c.get_value("s", "last_added", 0)
	remaining = ceili(end_unix - _now())
	for t in WARN_POINTS:
		if remaining <= t:
			_fired[t] = true
	session_resumed.emit()
