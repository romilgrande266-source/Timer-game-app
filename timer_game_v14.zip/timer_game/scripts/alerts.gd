extends CanvasLayer
## Toasts, warning sounds, notifications and screen routing (autoload "Alerts").

const HOME := "res://scenes/Main.tscn"
const SESSION := "res://scenes/Session.tscn"
const ADMIN := "res://scenes/Admin.tscn"

var _fade: ColorRect
var _band: CenterContainer
var _panel: PanelContainer
var _label: Label
var _tween: Tween
var _busy := false


func _ready() -> void:
	layer = 100
	process_mode = Node.PROCESS_MODE_ALWAYS
	_band = CenterContainer.new()
	_band.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	_band.offset_top = 20
	_band.offset_bottom = 110
	_band.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_band)
	_panel = PanelContainer.new()
	_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.modulate.a = 0.0
	_band.add_child(_panel)
	_label = Label.new()
	_label.theme = UIKit.theme()
	_label.add_theme_font_size_override("font_size", 28)
	_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(_label)
	_fade = ColorRect.new()
	_fade.color = Color(0, 0, 0, 0)
	_fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_fade)

	GameState.time_added.connect(_on_added)
	GameState.session_started.connect(_on_started)
	GameState.session_resumed.connect(_ensure_route)
	GameState.warning.connect(_on_warning)
	GameState.session_expired.connect(_on_expired)
	GameState.session_reset.connect(_on_reset)


func toast(msg: String, bad := false) -> void:
	_label.text = msg
	_panel.add_theme_stylebox_override("panel", UIKit.panel_style(UIKit.RED if bad else UIKit.NEON))
	_panel.modulate.a = 1.0
	if _tween:
		_tween.kill()
	_tween = create_tween()
	_tween.tween_interval(2.4)
	_tween.tween_property(_panel, "modulate:a", 0.0, 0.5)


func go(path: String) -> void:
	var cur := get_tree().current_scene
	if _busy or (cur != null and cur.scene_file_path == path):
		return
	_busy = true
	var t := create_tween()
	t.tween_property(_fade, "color:a", 1.0, 0.2)
	await t.finished
	get_tree().change_scene_to_file(path)
	await get_tree().process_frame
	await get_tree().process_frame
	var t2 := create_tween()
	t2.tween_property(_fade, "color:a", 0.0, 0.25)
	await t2.finished
	_busy = false
	_ensure_route()


func _ensure_route() -> void:
	var cur := get_tree().current_scene
	if cur == null:
		return
	if GameState.active and cur.scene_file_path == HOME:
		go(SESSION)
	elif not GameState.active and cur.scene_file_path == SESSION:
		go(HOME)


func _on_started() -> void:
	OverlayBridge.notify("TIMER GAME", "Session started", 10)
	_ensure_route()


func _on_added(pesos: int, secs: int, extended: bool) -> void:
	SoundManager.play("coin")
	var added := UIKit.long_duration(secs)
	if pesos == 0:   # custom timer (admin), not a coin payment
		if extended:
			toast("CUSTOM TIME ADDED  +%s" % added)
			OverlayBridge.notify("Additional time added", "+%s. Remaining %s" % [added, UIKit.hms(GameState.remaining)], 12)
		else:
			toast("CUSTOM TIMER STARTED  -  %s" % added)
			OverlayBridge.notify("Custom timer started", "%s" % added, 11)
		return
	if extended:
		toast("₱%d PAID  -  ADDITIONAL TIME ADDED  +%s" % [pesos, added])
		OverlayBridge.notify("Additional time added", "+%s (₱%d). Remaining %s" % [added, pesos, UIKit.hms(GameState.remaining)], 12)
	else:
		toast("₱%d PAID  -  +%s" % [pesos, added])
		OverlayBridge.notify("Payment received", "₱%d received: +%s" % [pesos, added], 11)


func _on_warning(point: int) -> void:
	match point:
		60:
			toast("1 MINUTE REMAINING", true)
			OverlayBridge.notify("One minute remaining", "Insert coin to add time", 13)
		59:
			SoundManager.play("beep")   # beep only, no voice
		10:
			SoundManager.play("beep")   # same beep as 00:59, no voice
			toast("10 SECONDS - PLEASE INSERT COIN!", true)
			OverlayBridge.notify("10 seconds remaining", "Please insert coin!", 14)


func _on_expired() -> void:
	SoundManager.play("timesup")
	toast("TIME'S UP", true)
	OverlayBridge.notify("Time expired", "Insert coin to start a new session", 15)
	go(HOME)


func _on_reset() -> void:
	toast("SESSION RESET BY ADMIN", true)
	go(HOME)
