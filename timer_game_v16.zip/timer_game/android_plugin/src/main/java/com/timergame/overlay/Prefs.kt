package com.timergame.overlay

import android.content.Context

/** Shared state between the Godot plugin and the foreground service (survives service restarts). */
object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("timer_game", Context.MODE_PRIVATE)

    fun endMs(c: Context): Long = p(c).getLong("endMs", 0L)
    fun setEndMs(c: Context, v: Long) = p(c).edit().putLong("endMs", v).apply()

    fun show(c: Context) = p(c).getBoolean("show", false)
    fun sizePct(c: Context) = p(c).getInt("size", 100)
    fun alphaPct(c: Context) = p(c).getInt("alpha", 90)
    fun volume(c: Context) = p(c).getInt("volume", 80)
    fun muted(c: Context) = p(c).getBoolean("muted", false)

    /** Coin buttons shown on the floating timer: "pesos:seconds,pesos:seconds". Empty = no buttons. */
    fun coinSpec(c: Context): String = p(c).getString("coins", "") ?: ""

    fun saveConfig(c: Context, show: Boolean, size: Int, alpha: Int, volume: Int, muted: Boolean, coins: String) {
        p(c).edit().putBoolean("show", show).putInt("size", size.coerceIn(50, 200))
            .putInt("alpha", alpha.coerceIn(20, 100)).putInt("volume", volume.coerceIn(0, 100))
            .putBoolean("muted", muted).putString("coins", coins).apply()
    }

    /** Coins tapped on the floating timer while the Godot app was away; Godot books them on return. */
    @Synchronized
    fun addPending(c: Context, pesos: Int) {
        val cur = p(c).getString("pending", "") ?: ""
        p(c).edit().putString("pending", if (cur.isEmpty()) "$pesos" else "$cur,$pesos").apply()
    }

    @Synchronized
    fun takePending(c: Context): String {
        val cur = p(c).getString("pending", "") ?: ""
        if (cur.isNotEmpty()) p(c).edit().remove("pending").apply()
        return cur
    }

    fun setShow(c: Context, v: Boolean) = p(c).edit().putBoolean("show", v).apply()

    /** 0 = nothing, 1 = bubble hidden from the notification, 2 = bubble shown from the notification. */
    fun setNotifToggle(c: Context, v: Int) = p(c).edit().putInt("notif_toggle", v).apply()
    fun consumeNotifToggle(c: Context): Int {
        val v = p(c).getInt("notif_toggle", 0)
        if (v != 0) setNotifToggle(c, 0)
        return v
    }

    fun collapsed(c: Context) = p(c).getBoolean("collapsed", false)
    fun setCollapsed(c: Context, v: Boolean) = p(c).edit().putBoolean("collapsed", v).apply()

    fun x(c: Context) = p(c).getInt("x", 40)
    fun y(c: Context) = p(c).getInt("y", 120)
    fun savePos(c: Context, x: Int, y: Int) = p(c).edit().putInt("x", x).putInt("y", y).apply()
}
