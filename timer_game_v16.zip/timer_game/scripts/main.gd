extends Control
## HOME SCREEN

var _insert: Label
var _sub: Label
var _rows := {}
var _test_panel: Control
var _settings_layer: Control
var _swipe: SwipeScroll
var _acc := 0.0
var _t := 0.0


func _ready() -> void:
	theme = UIKit.theme()
	UIKit.add_background(self)
	_build()
	_refresh()
	Settings.changed.connect(_refresh)
	OverlayBridge.status_changed.connect(_refresh)
	CoinService.hw_status_changed.connect(_refresh)
	if GameState.active:
		Alerts.go.call_deferred(Alerts.SESSION)


func _build() -> void:
	var scroll := ScrollContainer.new()
	scroll.set_anchors_preset(Control.PRESET_FULL_RECT)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(scroll)
	_swipe = UIKit.swipe(scroll)
	var margin := MarginContainer.new()
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 28)
	scroll.add_child(margin)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 18)
	margin.add_child(col)

	var head := HBoxContainer.new()
	head.alignment = BoxContainer.ALIGNMENT_CENTER
	head.add_theme_constant_override("separation", 18)
	head.add_child(CoinIcon.new())
	var tv := VBoxContainer.new()
	tv.add_child(UIKit.label("TIMER GAME", 64, UIKit.NEON))
	tv.add_child(UIKit.label("COIN-OPERATED COMPUTER TIMER", 20, UIKit.MUTED))
	head.add_child(tv)
	col.add_child(head)

	_insert = UIKit.label("INSERT COIN", 60, UIKit.GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	col.add_child(_insert)
	_sub = UIKit.label("", 22, UIKit.MUTED, HORIZONTAL_ALIGNMENT_CENTER)
	col.add_child(_sub)

	var flow := HFlowContainer.new()
	flow.alignment = FlowContainer.ALIGNMENT_CENTER
	flow.add_theme_constant_override("h_separation", 20)
	flow.add_theme_constant_override("v_separation", 20)
	col.add_child(flow)

	var pa := UIKit.panel()
	pa.custom_minimum_size.x = 520
	flow.add_child(pa)
	var va := VBoxContainer.new()
	va.add_theme_constant_override("separation", 10)
	pa.add_child(va)
	va.add_child(UIKit.label("SESSION STATUS", 26, UIKit.NEON))
	_row(va, "session", "Current session")
	_row(va, "start", "Start session")
	_row(va, "sound", "Sound")
	_row(va, "overlay", "Floating timer")
	_row(va, "hw", "Coin acceptor")

	var pb := UIKit.panel()
	pb.custom_minimum_size.x = 520
	flow.add_child(pb)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	pb.add_child(vb)
	vb.add_child(UIKit.label("COIN  →  TIME", 26, UIKit.NEON))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 50)
	grid.add_theme_constant_override("v_separation", 8)
	vb.add_child(grid)
	for p in GameState.COIN_TABLE:
		grid.add_child(UIKit.label("₱%d" % p, 30, UIKit.GOLD))
		grid.add_child(UIKit.label(UIKit.long_duration(GameState.COIN_TABLE[p]), 26))

	_test_panel = UIKit.panel(UIKit.GOLD)
	col.add_child(_test_panel)
	var vt := VBoxContainer.new()
	vt.add_theme_constant_override("separation", 10)
	_test_panel.add_child(vt)
	vt.add_child(UIKit.label("TEST MODE - SIMULATED PAYMENT (not a real coin)", 22, UIKit.GOLD))
	var tf := HFlowContainer.new()
	tf.add_theme_constant_override("h_separation", 12)
	tf.add_theme_constant_override("v_separation", 12)
	vt.add_child(tf)
	for p in GameState.COIN_TABLE:
		var b := UIKit.button("INSERT ₱%d" % p, 72, 26)
		b.custom_minimum_size.x = 190
		b.pressed.connect(CoinService.insert_test.bind(p))
		tf.add_child(b)

	var bottom := HBoxContainer.new()
	bottom.add_theme_constant_override("separation", 16)
	col.add_child(bottom)
	var bs := UIKit.button("⚙  SETTINGS", 72, 26)
	bs.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bs.pressed.connect(func(): _settings_layer.visible = true)
	var ba := UIKit.button("ADMIN", 72, 26)
	ba.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ba.pressed.connect(func(): Alerts.go(Alerts.ADMIN))
	bottom.add_child(bs)
	bottom.add_child(ba)

	_build_settings_layer()
	_swipe.blocked_by = _settings_layer   # while Settings is open only its own list scrolls


func _row(parent: Control, key: String, title: String) -> void:
	var h := HBoxContainer.new()
	var a := UIKit.label(title, 22, UIKit.MUTED)
	a.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var b := UIKit.label("-", 22, Color.WHITE, HORIZONTAL_ALIGNMENT_RIGHT)
	b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	b.custom_minimum_size.x = 260
	h.add_child(a)
	h.add_child(b)
	parent.add_child(h)
	_rows[key] = b


func _build_settings_layer() -> void:
	_settings_layer = Control.new()
	_settings_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	_settings_layer.visible = false
	add_child(_settings_layer)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.75)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	_settings_layer.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	_settings_layer.add_child(center)
	var p := UIKit.panel(UIKit.NEON)
	p.custom_minimum_size = Vector2(780, 0)
	center.add_child(p)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	p.add_child(v)
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(0, 480)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(sc)
	UIKit.swipe(sc)
	var inner := VBoxContainer.new()
	inner.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	inner.add_theme_constant_override("separation", 24)
	sc.add_child(inner)
	inner.add_child(SoundPanel.new())
	inner.add_child(OverlayPanel.new())
	var close := UIKit.button("CLOSE", 64, 26)
	close.pressed.connect(func(): _settings_layer.visible = false)
	v.add_child(close)


func _refresh() -> void:
	var active := GameState.active
	_rows["session"].text = ("ACTIVE  " + UIKit.hms(GameState.remaining)) if active else "IDLE"
	_rows["start"].text = "Running" if active else "Waiting for payment"
	_rows["sound"].text = "MUTED" if Settings.muted else "Volume %d%%" % int(Settings.volume * 100.0)
	_rows["overlay"].text = OverlayBridge.status_text()
	_rows["hw"].text = CoinService.hw_status_text()
	_insert.text = "SESSION ACTIVE" if active else "INSERT COIN"
	if Settings.test_mode:
		_sub.text = "Test mode is ON - use the simulated payment buttons below"
	elif Settings.hw_enabled:
		_sub.text = "Insert coins into the coin acceptor to start your session"
	else:
		_sub.text = "No payment input is enabled - open ADMIN"
	_test_panel.visible = Settings.test_mode


func _process(delta: float) -> void:
	_t += delta
	_acc += delta
	_insert.modulate.a = 0.55 + 0.45 * sin(_t * 4.0)
	if _acc >= 0.5:
		_acc = 0.0
		_refresh()
