extends Node
## Procedurally generated computer-shop sounds + text-to-speech (autoload "SoundManager").

const RATE := 22050
var _sounds := {}
var _players: Array[AudioStreamPlayer] = []
var _next := 0


func _ready() -> void:
	for i in 3:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_players.append(p)
	_sounds["coin"] = _seq([_tone(988, 0.08, 0.6, 0.2), _tone(1319, 0.25, 0.6, 0.2)])
	_sounds["chime"] = _seq([_tone(660, 0.1, 0.5, 0.0), _tone(880, 0.1, 0.5, 0.0), _tone(1100, 0.2, 0.5, 0.0)])
	_sounds["notify"] = _seq([_tone(800, 0.06, 0.5, 0.3), _tone(1200, 0.1, 0.5, 0.3)])
	_sounds["beep"] = _seq([_pure(1000, 0.18), _gap(0.12), _pure(1000, 0.18), _gap(0.12), _pure(1000, 0.18)])  # real beep-beep-beep (0.78 s), same as the Android background service
	_sounds["urgent"] = _seq([_tone(1800, 0.08, 0.7, 0.9), _gap(0.06), _tone(1800, 0.08, 0.7, 0.9), _gap(0.06), _tone(1800, 0.08, 0.7, 0.9)])
	_sounds["timesup"] = _seq([_tone(1200, 0.18), _tone(900, 0.18), _tone(700, 0.18), _tone(500, 0.18), _tone(300, 0.6)])
	Settings.changed.connect(apply_settings)
	apply_settings()


func apply_settings() -> void:
	AudioServer.set_bus_mute(0, Settings.muted)
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(Settings.volume, 0.0001)))
	if Settings.muted and DisplayServer.has_feature(DisplayServer.FEATURE_TEXT_TO_SPEECH):
		DisplayServer.tts_stop()


func play(sound: String) -> void:
	if Settings.muted or not _sounds.has(sound):
		return
	var p := _players[_next]
	_next = (_next + 1) % _players.size()
	p.stream = _sounds[sound]
	p.play()


func speak(text: String) -> void:
	if Settings.muted or not Settings.voice_enabled:
		return
	if not DisplayServer.has_feature(DisplayServer.FEATURE_TEXT_TO_SPEECH):
		play("notify")
		return
	var voices := DisplayServer.tts_get_voices_for_language("en")
	if voices.is_empty():
		play("notify")   # no TTS voice installed on this device
		return
	DisplayServer.tts_stop()
	DisplayServer.tts_speak(text, voices[0], clampi(int(Settings.volume * 100.0), 1, 100), 0.85, 0.95)


func _tone(freq: float, dur: float, vol := 0.6, square := 0.5) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	for i in n:
		var t := float(i) / RATE
		var s := sin(TAU * freq * t)
		var sq := 1.0 if s >= 0.0 else -1.0
		var env := minf(1.0, minf(t / 0.005, (dur - t) / 0.01))
		out[i] = lerpf(s, sq, square) * vol * env
	return out


## Clean, loud "real" beep: pure 1 kHz sine + a little 2nd harmonic, soft attack/release (no buzzy square wave).
func _pure(freq: float, dur: float, vol := 0.95) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	for i in n:
		var t := float(i) / RATE
		var v := (sin(TAU * freq * t) + 0.25 * sin(TAU * freq * 2.0 * t)) / 1.25
		var env := minf(1.0, minf(t / 0.008, (dur - t) / 0.012))
		out[i] = v * vol * env
	return out


func _gap(dur: float) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	out.resize(int(dur * RATE))
	return out


func _seq(parts: Array) -> AudioStreamWAV:
	var all := PackedFloat32Array()
	for p in parts:
		all.append_array(p)
	var bytes := PackedByteArray()
	bytes.resize(all.size() * 2)
	for i in all.size():
		bytes.encode_s16(i * 2, int(clampf(all[i], -1.0, 1.0) * 32767.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = bytes
	return w
