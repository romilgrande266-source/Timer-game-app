extends Node
## Bridge to the Android "TimerOverlay" native plugin (autoload "OverlayBridge").
## The native foreground service owns the floating window and keeps counting
## (and warning) while Godot is paused in the background.

signal status_changed

var plugin = null
var _poll := 0.0


func _ready() -> void:
	if OS.get_name() == "Android" and Engine.has_singleton("TimerOverlay"):
		plugin = Engine.get_singleton("TimerOverlay")
		plugin.requestNotificationPermission()
	Settings.changed.connect(_push_config)
	GameState.time_added.connect(func(_a, _b, _c): sync())
	GameState.session_resumed.connect(sync)
	GameState.session_expired.connect(sync)
	GameState.session_reset.connect(sync)
	_sync_from_notification()   # BEFORE _push_config(): honour "Stop bubble" pressed on the notification
	_push_config()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_RESUMED:
		status_changed.emit()   # user may have just granted the permission
		_sync_from_notification()
		apply_overlay_coins()   # BEFORE sync(): coins tapped on the floating timer count first
		_push_config()
		sync()


func _process(delta: float) -> void:
	_poll += delta
	if _poll >= 1.0:
		_poll = 0.0
		apply_overlay_coins()


## Book the coins that were tapped on the floating timer while this app was in the background.
func apply_overlay_coins() -> void:
	if plugin == null:
		return
	var raw := str(plugin.takePendingCoins())
	if raw == "":
		return
	var list := []
	for part in raw.split(","):
		if part.is_valid_int():
			list.append(part.to_int())
	GameState.apply_overlay_payments(list, str(plugin.nativeEndMs()).to_float() / 1000.0)


## "Stop bubble" / "Show bubble" pressed on the notification while the app was in the background.
func _sync_from_notification() -> void:
	if plugin == null:
		return
	var t: int = plugin.consumeBubbleToggle()
	if t == 1:
		Settings.update("overlay_visible", false)
	elif t == 2:
		Settings.update("overlay_visible", true)


func is_available() -> bool:
	return plugin != null


func has_permission() -> bool:
	return plugin != null and plugin.hasOverlayPermission()


func request_permission() -> void:
	if plugin != null:
		plugin.requestOverlayPermission()


func set_enabled(on: bool) -> void:
	Settings.update("overlay_enabled", on)
	if on and plugin != null and not plugin.hasOverlayPermission():
		plugin.requestOverlayPermission()
	status_changed.emit()


func status_text() -> String:
	if OS.get_name() != "Android":
		return "Android only"
	if plugin == null:
		return "Native plugin not installed (see README)"
	if not Settings.overlay_enabled:
		return "Disabled"
	if not plugin.hasOverlayPermission():
		return "Permission NOT granted - grant 'Display over other apps'"
	if not Settings.overlay_visible:
		return "Enabled (hidden)"
	return "Enabled - shown during session"


## Android battery optimisation: if the app is NOT exempt, some phones (Oppo, Xiaomi, Realme...) kill the background timer.
func background_allowed() -> bool:
	return plugin != null and plugin.isBackgroundAllowed()


func request_background() -> void:
	if plugin != null:
		plugin.requestBackgroundRun()


func status_ok() -> bool:
	return plugin != null and Settings.overlay_enabled and plugin.hasOverlayPermission()


func _push_config() -> void:
	if plugin == null:
		return
	var show: bool = Settings.overlay_enabled and Settings.overlay_visible and plugin.hasOverlayPermission()
	plugin.configure(show, int(Settings.overlay_size * 100.0), int(Settings.overlay_alpha * 100.0),
		int(Settings.volume * 100.0), Settings.muted, _coin_spec())


## Coin buttons on the floating timer: TEST MODE only (same rule as the on-screen buttons),
## and only the coin values the admin left enabled. "pesos:seconds,pesos:seconds"
func _coin_spec() -> String:
	if not Settings.test_mode or not Settings.overlay_coin_buttons:
		return ""
	var parts := PackedStringArray()
	for p in GameState.COIN_TABLE:
		if Settings.coin_enabled.get(p, true):
			parts.append("%d:%d" % [p, GameState.COIN_TABLE[p]])
	return ",".join(parts)


func sync() -> void:
	if plugin == null:
		return
	if GameState.active:
		# seconds_left(), not remaining: remaining is stale right after the app comes back from the background
		var left := GameState.seconds_left()
		if left > 0:
			plugin.startSession(left)   # native side counts down by itself
	else:
		plugin.stopSession()


func notify(title: String, text: String, id: int) -> void:
	if plugin != null:
		plugin.postNotification(title, text, id)
