class_name SwipeScroll
extends Node
## Swipe up / down ANYWHERE on a ScrollContainer (even when the finger starts on a button or panel),
## with fling momentum. Add it as a child of the ScrollContainer. Sliders / spin boxes / text fields
## keep their own drag. A swipe never triggers the button it started on.

var blocked_by: Control = null   # while this control is visible, this scroller ignores swipes
var _sc: ScrollContainer
var _down := false
var _drag := false
var _start := Vector2.ZERO
var _pos := 0.0
var _vel := 0.0
var _last_t := 0
const THRESH := 12.0


func _ready() -> void:
	_sc = get_parent() as ScrollContainer


func _active() -> bool:
	return _sc != null and _sc.is_visible_in_tree() and (blocked_by == null or not blocked_by.visible)


func _max() -> float:
	var bar := _sc.get_v_scroll_bar()
	return maxf(bar.max_value - bar.page, 0.0)


func _input(e: InputEvent) -> void:
	if not _active():
		return
	# Stop the container's own touch-scroll so it does not scroll twice.
	if e is InputEventScreenDrag and _down:
		get_viewport().set_input_as_handled()
		return
	if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
		if e.pressed:
			_drag = false
			_vel = 0.0
			_start = e.position
			_pos = float(_sc.scroll_vertical)
			_last_t = Time.get_ticks_msec()
			_down = _sc.get_global_rect().has_point(e.position) and _find(_sc, e.position, true).is_empty()
		else:
			if Time.get_ticks_msec() - _last_t > 100:
				_vel = 0.0   # finger rested before lifting: no fling
			_down = false
			_drag = false
	elif e is InputEventMouseMotion and _down:
		var d: Vector2 = e.position - _start
		if not _drag:
			if absf(d.y) > THRESH and absf(d.y) > absf(d.x) * 1.5:
				_drag = true
				for b in _find(_sc, _start, false):   # cancel the press so the swipe is not a tap
					b.disabled = true
					b.disabled = false
			else:
				return
		var now := Time.get_ticks_msec()
		var dt := maxf((now - _last_t) / 1000.0, 0.001)
		_last_t = now
		_pos = clampf(_pos - e.relative.y, 0.0, _max())
		_sc.scroll_vertical = int(_pos)
		_vel = lerpf(_vel, -e.relative.y / dt, 0.4)


func _process(delta: float) -> void:
	if _down or absf(_vel) < 30.0 or not _active():
		return
	_pos = clampf(_pos + _vel * delta, 0.0, _max())
	_sc.scroll_vertical = int(_pos)
	_vel *= pow(0.02, delta)
	if _pos <= 0.0 or _pos >= _max():
		_vel = 0.0


## Controls under a screen point. keep_drag_controls = true: sliders/spinboxes/text fields (they keep their own drag);
## false: buttons (their press gets cancelled when a swipe starts).
func _find(n: Node, pos: Vector2, keep_drag_controls: bool) -> Array:
	var out := []
	for c in n.get_children():
		if c is Control and c.is_visible_in_tree():
			var r: Rect2 = c.get_global_rect().grow(20)
			if r.has_point(pos):
				if keep_drag_controls and (c is Range or c is LineEdit or c is TextEdit):
					out.append(c)
				elif not keep_drag_controls and c is BaseButton:
					out.append(c)
		out.append_array(_find(c, pos, keep_drag_controls))
	return out
