class_name OverlayPanel
extends VBoxContainer
## Floating timer controls: enable/disable, show/hide, size, transparency, position reset.

var _status: Label
var _enable: CheckButton
var _hide_btn: Button
var _bg: Label
var _coins: CheckButton


func _ready() -> void:
	add_theme_constant_override("separation", 12)
	add_child(UIKit.label("FLOATING TIMER", 26, UIKit.NEON))
	_status = UIKit.label("", 20)
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	add_child(_status)
	var hint := UIKit.label("Small timer box shows over other apps when you leave this app. Tap ✕ to shrink it to a circle, tap the circle to open the box again. Drag to move.", 18, UIKit.MUTED)
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	add_child(hint)
	_enable = CheckButton.new()
	_enable.text = "Enable floating timer"
	_enable.custom_minimum_size = Vector2(0, 52)
	_enable.toggled.connect(func(on: bool): OverlayBridge.set_enabled(on))
	add_child(_enable)
	var grant := UIKit.button("GRANT 'DISPLAY OVER OTHER APPS' PERMISSION", 52, 18)
	grant.pressed.connect(func(): OverlayBridge.request_permission())
	add_child(grant)
	_bg = UIKit.label("", 20)
	_bg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	add_child(_bg)
	var bgbtn := UIKit.button("ALLOW RUNNING IN BACKGROUND", 56, 20)
	bgbtn.pressed.connect(func(): OverlayBridge.request_background())
	add_child(bgbtn)
	_hide_btn = UIKit.button("", 64, 24)
	_hide_btn.pressed.connect(func(): Settings.update("overlay_visible", not Settings.overlay_visible))
	add_child(_hide_btn)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	add_child(row)
	var b_circle := UIKit.button("SHRINK TO CIRCLE", 56, 20)
	b_circle.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b_circle.pressed.connect(func(): _collapse(true))
	row.add_child(b_circle)
	var b_box := UIKit.button("OPEN TIME BOX", 56, 20)
	b_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b_box.pressed.connect(func(): _collapse(false))
	row.add_child(b_box)
	_coins = CheckButton.new()
	_coins.text = "Coin buttons on the floating box (test mode)"
	_coins.custom_minimum_size = Vector2(0, 52)
	_coins.toggled.connect(func(on: bool): Settings.update("overlay_coin_buttons", on))
	add_child(_coins)
	_slider("Size", 50, 200, Settings.overlay_size * 100.0, "overlay_size")
	_slider("Transparency (opacity)", 20, 100, Settings.overlay_alpha * 100.0, "overlay_alpha")
	var reset := UIKit.button("RESET POSITION", 52, 18)
	reset.pressed.connect(func():
		if OverlayBridge.plugin != null:
			OverlayBridge.plugin.resetPosition())
	add_child(reset)
	Settings.changed.connect(_refresh)
	OverlayBridge.status_changed.connect(_refresh)
	_refresh()


func _collapse(c: bool) -> void:
	if OverlayBridge.plugin != null:
		OverlayBridge.plugin.setCollapsed(c)


func _slider(title: String, lo: float, hi: float, val: float, key: String) -> void:
	var row := HBoxContainer.new()
	add_child(row)
	var l := UIKit.label(title, 20)
	l.custom_minimum_size = Vector2(230, 0)
	row.add_child(l)
	var s := HSlider.new()
	s.min_value = lo
	s.max_value = hi
	s.step = 5
	s.value = val
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.custom_minimum_size = Vector2(0, 44)
	s.value_changed.connect(func(v: float): Settings.update(key, v / 100.0))
	row.add_child(s)


func _refresh() -> void:
	_status.text = "Status: " + OverlayBridge.status_text()
	_status.add_theme_color_override("font_color", UIKit.GREEN if OverlayBridge.status_ok() else UIKit.GOLD)
	_enable.set_pressed_no_signal(Settings.overlay_enabled)
	if OverlayBridge.is_available():
		var ok := OverlayBridge.background_allowed()
		_bg.text = "Background running: " + ("ALLOWED - timer keeps running and beeps while you use other apps" if ok else "NOT allowed yet - tap the button below, then choose 'Allow'")
		_bg.add_theme_color_override("font_color", UIKit.GREEN if ok else UIKit.GOLD)
	else:
		_bg.text = "Background running: Android only"
	_hide_btn.text = "HIDE COIN BOX" if Settings.overlay_visible else "SHOW COIN BOX"
	_coins.set_pressed_no_signal(Settings.overlay_coin_buttons)
