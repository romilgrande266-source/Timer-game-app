package com.timergame.overlay

import android.content.Context
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.util.Properties

/**
 * State shared between the Godot app process and the bubble service process (":overlay").
 * SharedPreferences is NOT safe across processes, so this is a tiny file store with a file lock.
 */
object Prefs {
    private const val NAME = "tg_prefs.properties"

    private fun file(c: Context) = File(c.applicationContext.filesDir, NAME)

    private fun read(c: Context): Properties {
        val p = Properties()
        try { FileInputStream(file(c)).use { p.load(it) } } catch (_: Exception) {}
        return p
    }

    @Synchronized
    private fun edit(c: Context, block: (Properties) -> Unit) {
        val dir = c.applicationContext.filesDir
        try {
            RandomAccessFile(File(dir, "$NAME.lock"), "rw").use { raf ->
                val lock = raf.channel.lock()
                try {
                    val p = read(c)
                    block(p)
                    val tmp = File(dir, "$NAME.tmp")
                    FileOutputStream(tmp).use { p.store(it, null) }
                    tmp.renameTo(file(c))
                } finally {
                    lock.release()
                }
            }
        } catch (_: Exception) {}
    }

    private fun str(c: Context, k: String, d: String) = read(c).getProperty(k, d)
    private fun int(c: Context, k: String, d: Int) = str(c, k, d.toString()).toIntOrNull() ?: d
    private fun bool(c: Context, k: String, d: Boolean) = str(c, k, d.toString()).toBooleanStrictOrNull() ?: d

    fun endMs(c: Context): Long = str(c, "endMs", "0").toLongOrNull() ?: 0L
    fun setEndMs(c: Context, v: Long) = edit(c) { it.setProperty("endMs", v.toString()) }

    /** true while the Godot app is on screen (set by the plugin; read by the service process). */
    fun fg(c: Context) = bool(c, "fg", false)
    fun setFg(c: Context, v: Boolean) = edit(c) { it.setProperty("fg", v.toString()) }

    fun show(c: Context) = bool(c, "show", false)
    fun sizePct(c: Context) = int(c, "size", 100)
    fun alphaPct(c: Context) = int(c, "alpha", 90)
    fun volume(c: Context) = int(c, "volume", 80)
    fun muted(c: Context) = bool(c, "muted", false)

    /** Coin buttons shown on the floating timer: "pesos:seconds,pesos:seconds". Empty = no buttons. */
    fun coinSpec(c: Context): String = str(c, "coins", "")

    fun saveConfig(c: Context, show: Boolean, size: Int, alpha: Int, volume: Int, muted: Boolean, coins: String) =
        edit(c) {
            it.setProperty("show", show.toString())
            it.setProperty("size", size.coerceIn(50, 200).toString())
            it.setProperty("alpha", alpha.coerceIn(20, 100).toString())
            it.setProperty("volume", volume.coerceIn(0, 100).toString())
            it.setProperty("muted", muted.toString())
            it.setProperty("coins", coins)
        }

    /** Coins tapped on the floating timer while the Godot app was away; Godot books them on return. */
    fun addPending(c: Context, pesos: Int) = edit(c) {
        val cur = it.getProperty("pending", "")
        it.setProperty("pending", if (cur.isEmpty()) "$pesos" else "$cur,$pesos")
    }

    fun takePending(c: Context): String {
        var out = ""
        edit(c) {
            out = it.getProperty("pending", "")
            if (out.isNotEmpty()) it.remove("pending")
        }
        return out
    }

    fun setShow(c: Context, v: Boolean) = edit(c) { it.setProperty("show", v.toString()) }

    /** 0 = nothing, 1 = bubble hidden from the notification, 2 = bubble shown from the notification. */
    fun setNotifToggle(c: Context, v: Int) = edit(c) { it.setProperty("notif_toggle", v.toString()) }
    fun consumeNotifToggle(c: Context): Int {
        var v = 0
        edit(c) {
            v = it.getProperty("notif_toggle", "0").toIntOrNull() ?: 0
            if (v != 0) it.setProperty("notif_toggle", "0")
        }
        return v
    }

    fun collapsed(c: Context) = bool(c, "collapsed", false)
    fun setCollapsed(c: Context, v: Boolean) = edit(c) { it.setProperty("collapsed", v.toString()) }

    fun x(c: Context) = int(c, "x", 40)
    fun y(c: Context) = int(c, "y", 120)
    fun savePos(c: Context, x: Int, y: Int) = edit(c) {
        it.setProperty("x", x.toString())
        it.setProperty("y", y.toString())
    }
}
