package com.timergame.overlay

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import org.godotengine.godot.Godot
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.UsedByGodot

/**
 * Godot singleton "TimerOverlay". Only int / boolean / String parameters are used,
 * which map safely between GDScript and Kotlin.
 */
class TimerOverlayPlugin(godot: Godot) : GodotPlugin(godot) {

    override fun getPluginName() = "TimerOverlay"

    private fun ctx(): Context? = activity?.applicationContext

    @UsedByGodot
    fun hasOverlayPermission(): Boolean = ctx()?.let { Settings.canDrawOverlays(it) } ?: false

    @UsedByGodot
    fun requestOverlayPermission() {
        val a = activity ?: return
        a.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.packageName))
        )
    }

    @UsedByGodot
    fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            activity?.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7001)
        }
    }

    @UsedByGodot
    fun configure(show: Boolean, sizePct: Int, alphaPct: Int, volumePct: Int, muted: Boolean, coins: String) {
        val c = ctx() ?: return
        Prefs.saveConfig(c, show, sizePct, alphaPct, volumePct, muted, coins)
        OverlayService.requestReload(c)
    }

    /** "5,10,1" = coins tapped on the floating timer since Godot last asked (cleared on read). */
    @UsedByGodot
    fun takePendingCoins(): String {
        val c = ctx() ?: return ""
        return Prefs.takePending(c)
    }

    /** End of the native countdown, unix milliseconds, as a String (Long is not safe across the bridge). */
    @UsedByGodot
    fun nativeEndMs(): String {
        val c = ctx() ?: return "0"
        return Prefs.endMs(c).toString()
    }

    /** (Re)start the native countdown with the given remaining seconds. */
    @UsedByGodot
    fun startSession(remainingSec: Int) {
        val c = ctx() ?: return
        Prefs.setEndMs(c, System.currentTimeMillis() + remainingSec * 1000L)
        val i = Intent(c, OverlayService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        } catch (e: Exception) {
            // Background-start restriction: the service will be started on the next foreground sync.
        }
    }

    @UsedByGodot
    fun stopSession() {
        val c = ctx() ?: return
        Prefs.setEndMs(c, 0L)
        c.stopService(Intent(c, OverlayService::class.java))
    }

    @UsedByGodot
    fun resetPosition() {
        val c = ctx() ?: return
        Prefs.savePos(c, 40, 120)
        OverlayService.requestReload(c)
    }

    /** True when Android battery optimisation is switched off for this app (timer survives in the background). */
    @UsedByGodot
    fun isBackgroundAllowed(): Boolean {
        val c = ctx() ?: return false
        val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(c.packageName)
    }

    @UsedByGodot
    fun requestBackgroundRun() {
        val a = activity ?: return
        try {
            a.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:" + a.packageName)))
        } catch (_: Exception) {
            a.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    /** 1 = user pressed "Stop bubble" on the notification, 2 = "Show bubble", 0 = nothing (reading clears it). */
    @UsedByGodot
    fun consumeBubbleToggle(): Int {
        val c = ctx() ?: return 0
        return Prefs.consumeNotifToggle(c)
    }

    /** true = shrink the floating box to the circle, false = open the box with the time. */
    @UsedByGodot
    fun setCollapsed(collapsed: Boolean) {
        val c = ctx() ?: return
        Prefs.setCollapsed(c, collapsed)
        OverlayService.requestReload(c)
    }

    @UsedByGodot
    fun postNotification(title: String, text: String, id: Int) {
        ctx()?.let { Notifs.post(it, id, title, text) }
    }

    // While Godot is in the foreground it plays warnings itself; in the background the service does.
    // The floating timer is drawn only while the user is in OTHER apps, so re-evaluate on every switch.
    override fun onMainPause() {
        ctx()?.let { Prefs.setFg(it, false); OverlayService.requestReload(it) }
    }

    override fun onMainResume() {
        ctx()?.let { Prefs.setFg(it, true); OverlayService.requestReload(it) }
    }
}
