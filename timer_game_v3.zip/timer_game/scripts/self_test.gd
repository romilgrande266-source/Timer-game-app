class_name SelfTest
extends RefCounted
## Logic tests for the coin table, accumulation, warnings and expiry.
## Runs on a detached GameState instance with a fake clock (no waiting).

const GS := preload("res://scripts/game_state.gd")


static func _new():
	var g = GS.new()
	g.sandbox = true
	g.fake_now = 1000.0
	return g


static func run() -> Dictionary:
	var res := {"fails": 0, "log": []}
	var check = func(label: String, cond: bool) -> void:
		res["log"].append(("PASS  " if cond else "FAIL  ") + label)
		if not cond:
			res["fails"] += 1

	var expect := {1: 360, 5: 1200, 10: 3600, 15: 5400, 20: 7200}
	for p in expect:
		var g = _new()
		g.add_payment(p)
		check.call("₱%d adds %d s" % [p, expect[p]], g.remaining == expect[p] and g.active)
		g.free()

	var a = _new()
	a.add_payment(5)
	a.fake_now += 100.0
	a.step()
	a.add_payment(10)
	check.call("₱5 then ₱10 accumulates (no reset): 4700 s", a.remaining == 4700)
	a.free()

	var b = _new()
	var fired := []
	var st := {"expired": false}
	b.warning.connect(func(p): fired.append(p))
	b.session_expired.connect(func(): st["expired"] = true)
	b.add_payment(1)
	for i in 360:
		b.fake_now += 1.0
		b.step()
	check.call("Warnings fire exactly once each: 01:00, 00:59, 00:10", fired == [60, 59, 10])
	check.call("Expires at 00:00 and session becomes inactive", st["expired"] and not b.active)
	b.free()

	var c = _new()
	var fired2 := []
	c.warning.connect(func(p): fired2.append(p))
	c.add_payment(1)
	for i in 330:
		c.fake_now += 1.0
		c.step()
	c.add_payment(5)    # extend after the 01:00 warning
	for i in 1170:
		c.fake_now += 1.0
		c.step()
	check.call("Warnings re-arm after extra time is added", fired2 == [60, 59, 60])
	c.free()

	var log := PackedStringArray(res["log"])
	return {"ok": res["fails"] == 0, "log": "\n".join(log)}
