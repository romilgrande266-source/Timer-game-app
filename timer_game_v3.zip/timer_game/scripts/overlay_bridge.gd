extends Node
## Bridge to the Android "TimerOverlay" native plugin (autoload "OverlayBridge").
## The native foreground service owns the floating window and keeps counting
## (and warning) while Godot is paused in the background.

signal status_changed

var plugin = null


func _ready() -> void:
	if OS.get_name() == "Android" and Engine.has_singleton("TimerOverlay"):
		plugin = Engine.get_singleton("TimerOverlay")
		plugin.requestNotificationPermission()
	Settings.changed.connect(_push_config)
	GameState.time_added.connect(func(_a, _b, _c): sync())
	GameState.session_resumed.connect(sync)
	GameState.session_expired.connect(sync)
	GameState.session_reset.connect(sync)
	_push_config()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_RESUMED:
		status_changed.emit()   # user may have just granted the permission
		_push_config()
		sync()


func is_available() -> bool:
	return plugin != null


func has_permission() -> bool:
	return plugin != null and plugin.hasOverlayPermission()


func request_permission() -> void:
	if plugin != null:
		plugin.requestOverlayPermission()


func set_enabled(on: bool) -> void:
	Settings.update("overlay_enabled", on)
	if on and plugin != null and not plugin.hasOverlayPermission():
		plugin.requestOverlayPermission()
	status_changed.emit()


func status_text() -> String:
	if OS.get_name() != "Android":
		return "Android only"
	if plugin == null:
		return "Native plugin not installed (see README)"
	if not Settings.overlay_enabled:
		return "Disabled"
	if not plugin.hasOverlayPermission():
		return "Permission NOT granted - grant 'Display over other apps'"
	if not Settings.overlay_visible:
		return "Enabled (hidden)"
	return "Enabled - shown during session"


func status_ok() -> bool:
	return plugin != null and Settings.overlay_enabled and plugin.hasOverlayPermission()


func _push_config() -> void:
	if plugin == null:
		return
	var show: bool = Settings.overlay_enabled and Settings.overlay_visible and plugin.hasOverlayPermission()
	plugin.configure(show, int(Settings.overlay_size * 100.0), int(Settings.overlay_alpha * 100.0),
		int(Settings.volume * 100.0), Settings.muted)


func sync() -> void:
	if plugin == null:
		return
	if GameState.active:
		plugin.startSession(GameState.remaining)   # native side counts down by itself
	else:
		plugin.stopSession()


func notify(title: String, text: String, id: int) -> void:
	if plugin != null:
		plugin.postNotification(title, text, id)
