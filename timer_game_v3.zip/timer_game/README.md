# TIMER GAME – coin-operated computer timer (Godot 4.x)

Android + Windows. Dark/blue-neon cyber-cafe UI, seven-segment HH:MM:SS countdown,
coin→time table, accumulating payments, warning sounds + voice, auto return to Home,
Android floating timer (native foreground service), PIN-protected admin, test mode,
hardware coin-acceptor support.

## Coin table
₱1 = 6 min · ₱5 = 20 min · ₱10 = 1 h · ₱15 = 1 h 30 m · ₱20 = 2 h  (extra coins ADD time, never reset)

## Run (Windows / editor)
Open `project.godot` in Godot. Run. Default admin PIN: **1234** (change it in Admin).
TEST MODE is ON by default so you can simulate payments; turn it OFF in Admin for production.

## Logic self-test (no waiting; fake clock)
    godot --headless --path . res://tests/SelfTest.tscn
or Admin → DIAGNOSTICS → RUN LOGIC SELF-TEST. Covers: all 5 coin values, accumulation,
01:00 / 00:59 / 00:10 warnings firing exactly once, re-arming after added time, expiry at 00:00.

## Android build
1. Godot: Project → Install Android Build Template; Export preset Android with **Use Gradle Build** ON.
2. Build the plugin (needs Android Studio / Gradle + Android SDK):
   - Copy the Godot Android library AAR matching your editor version into `android_plugin/libs/`.
   - `cd android_plugin && gradle assembleRelease`
   - Copy `build/outputs/aar/*-release.aar` to `android/plugins/TimerOverlay.aar`
     (next to `TimerOverlay.gdap`).
3. In the Android export preset, tick the **TimerOverlay** plugin. Export.
4. First launch: Settings → Floating timer → enable → Android opens
   "Display over other apps"; grant it. The app only reports "Enabled" after the
   permission is really granted. Android 13+ also asks for notification permission.

How it works: Godot tells the native `OverlayService` the remaining seconds on every payment.
The service keeps its own end time (SharedPreferences), draws the draggable overlay,
and – only while the Godot app is in the background – plays the warning beeps/voice and posts
notifications, so nothing is doubled. It restarts itself if the system kills it.

## Real coins
Touchscreen buttons are TEST MODE only. For real coins use a pulse coin acceptor +
USB-HID microcontroller (`hardware/coin_acceptor_hid.ino`). It types
`TG,<pesos>,<secret>` + Enter (works on Windows and on Android via USB-OTG / Bluetooth keyboard)
plus a heartbeat every 5 s that drives the "Coin acceptor: Connected" status.
Copy the secret from Admin → Coin System into the sketch, enable "Hardware coin acceptor".
Programme the acceptor for 1 pulse = ₱1.

## Floating timer behaviour
Small box (coin + HH:MM:SS + ✕) over other apps (shown only while you are in another app; hidden when this app is on screen). Tap **✕** → it shrinks to a small gold coin circle
(border turns red in the last minute). Tap the circle → back to the box. Drag either one to move;
size/transparency in Settings. State is remembered while the session runs.

## Warning schedule
01:00 three beeps · 00:59 voice "Warning. You have one minute remaining." ·
00:10 urgent beeps + voice "Please insert coin!" · 00:00 Time's Up sound → app Home screen (if you are in another app, the phone goes to its Home screen),
overlay removed, session disabled.
Sounds are generated in code (no audio assets). Voice uses the OS text-to-speech
(needs an English TTS voice installed; falls back to a chime).

## Test checklist
Automated (self-test): items 1–10 logic (coin values, accumulation, warning triggers, expiry).
Manual on device: 11 overlay visible over other apps · 12 countdown continues while switching apps ·
13 overlay/app sync · hearing the actual beeps and voice · screen auto-return visually.

## Known limits
- Going to the phone Home screen at 00:00 uses a normal start from the background. It relies on the "Display over other apps" permission; some phone brands block it unless the app also has a background-pop-up / autostart permission.
- Written without access to Godot/Android SDK in the authoring environment: not compiled or run.
  Expect to fix small API/version issues on first open.
- Countdown uses the device wall clock; changing the system clock can cheat it (lock settings on a kiosk).
- On a PC the acceptor is a keyboard: the shared secret stops casual typing, but physically secure the machine.
- Windows has no overlay equivalent here; the full-screen app is the timer.

## GitHub
    git init && git add . && git commit -m "TIMER GAME"
    git branch -M main
    git remote add origin https://github.com/<your-user>/timer-game.git
    git push -u origin main

Every push to `main` runs **Build apk** (`.github/workflows/build-apk.yml`):
logic self-test -> builds the TimerOverlay native plugin AAR -> exports a debug-signed
`TimerGame.apk`. Download it from the run's **Artifacts** (TimerGame-apk) and install it.
`ci.yml` runs only the self-test on pull requests.
If the run fails on Android build-tools / NDK versions, change the three `ANDROID_*`
values at the top of the workflow to the versions the log names.

## Build APK on GitHub
Actions → **Build apk** → Run workflow. It builds the TimerOverlay plugin, the Godot
Android export (debug-signed, arm64) and uploads `TimerGame-apk` as an artifact.
Debug-signed APKs install fine for sideloading; use your own release keystore for Play Store.
