package com.timergame.overlay

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import org.godotengine.godot.Godot
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.UsedByGodot

/**
 * Godot singleton "TimerOverlay". Only int / boolean / String parameters are used,
 * which map safely between GDScript and Kotlin.
 */
class TimerOverlayPlugin(godot: Godot) : GodotPlugin(godot) {

    override fun getPluginName() = "TimerOverlay"

    private fun ctx(): Context? = activity?.applicationContext

    @UsedByGodot
    fun hasOverlayPermission(): Boolean = ctx()?.let { Settings.canDrawOverlays(it) } ?: false

    @UsedByGodot
    fun requestOverlayPermission() {
        val a = activity ?: return
        a.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.packageName))
        )
    }

    @UsedByGodot
    fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            activity?.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7001)
        }
    }

    @UsedByGodot
    fun configure(show: Boolean, sizePct: Int, alphaPct: Int, volumePct: Int, muted: Boolean) {
        val c = ctx() ?: return
        Prefs.saveConfig(c, show, sizePct, alphaPct, volumePct, muted)
        OverlayService.instance?.postReload()
    }

    /** (Re)start the native countdown with the given remaining seconds. */
    @UsedByGodot
    fun startSession(remainingSec: Int) {
        val c = ctx() ?: return
        Prefs.setEndMs(c, System.currentTimeMillis() + remainingSec * 1000L)
        val i = Intent(c, OverlayService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        } catch (e: Exception) {
            // Background-start restriction: the service will be started on the next foreground sync.
        }
    }

    @UsedByGodot
    fun stopSession() {
        val c = ctx() ?: return
        Prefs.setEndMs(c, 0L)
        c.stopService(Intent(c, OverlayService::class.java))
    }

    @UsedByGodot
    fun resetPosition() {
        val c = ctx() ?: return
        Prefs.savePos(c, 40, 120)
        OverlayService.instance?.postReload()
    }

    @UsedByGodot
    fun postNotification(title: String, text: String, id: Int) {
        ctx()?.let { Notifs.post(it, id, title, text) }
    }

    // While Godot is in the foreground it plays warnings itself; in the background the service does.
    // The floating timer is drawn only while the user is in OTHER apps, so re-evaluate on every switch.
    override fun onMainPause() {
        OverlayService.appForeground = false
        OverlayService.instance?.postReload()
    }

    override fun onMainResume() {
        OverlayService.appForeground = true
        OverlayService.instance?.postReload()
    }
}
