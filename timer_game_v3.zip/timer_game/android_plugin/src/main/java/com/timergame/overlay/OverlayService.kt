package com.timergame.overlay

import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.abs

/**
 * Foreground service that:
 *  - keeps counting down from the stored end time (independent of Godot),
 *  - shows the draggable floating timer over other apps (if permission granted),
 *  - plays the warning sounds / voice while the Godot app is in the background,
 *  - removes everything when the session expires.
 */
class OverlayService : Service() {

    companion object {
        @Volatile var appForeground = false   // set true/false by the plugin (onMainResume / onMainPause)
        @Volatile var instance: OverlayService? = null
        private const val ID_FG = 1
        private val CYAN = Color.rgb(34, 211, 255)
        private val RED = Color.rgb(255, 56, 96)
    }

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var root: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var boxView: View? = null
    private var bubbleView: TextView? = null
    private var timeView: TextView? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val fired = HashSet<Int>()
    private var lastShown = Int.MIN_VALUE

    private val loop = object : Runnable {
        override fun run() { tick(); handler.postDelayed(this, 250) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        Notifs.ensureChannels(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) tts?.language = Locale.US
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Prefs.endMs(this) <= System.currentTimeMillis()) {
            startFg()   // startForegroundService() must be answered before we stop
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startFg()
        reload()
        handler.removeCallbacks(loop)
        handler.post(loop)
        return START_STICKY   // restart safely after the system kills us; state is in Prefs
    }

    override fun onDestroy() {
        handler.removeCallbacks(loop)
        removeOverlay()
        tts?.shutdown()
        instance = null
        super.onDestroy()
    }

    fun postReload() { handler.post { reload() } }

    private fun remainingSec(): Int =
        Math.ceil((Prefs.endMs(this) - System.currentTimeMillis()) / 1000.0).toInt()

    private fun startFg() {
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, Notifs.CH_SESSION)
                else Notification.Builder(this)
        b.setSmallIcon(applicationInfo.icon)
            .setContentTitle("TIMER GAME - session running")
            .setContentText("Time remaining is counting down")
            .setOngoing(true)
            .setContentIntent(Notifs.launchIntent(this))
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setWhen(Prefs.endMs(this))
        val n = b.build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID_FG, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID_FG, n)
        }
    }

    /** Called whenever time was added or settings changed. */
    private fun reload() {
        val rem = remainingSec()
        fired.removeAll { rem > it }   // re-arm warnings that are in the future again
        lastShown = Int.MIN_VALUE
        removeOverlay()
        if (Prefs.show(this) && !appForeground && Settings.canDrawOverlays(this)) createOverlay()
        tick()
    }

    private fun tick() {
        val rem = remainingSec()
        if (rem == lastShown) return
        lastShown = rem
        timeView?.text = fmt(maxOf(rem, 0))
        timeView?.setTextColor(if (rem <= 60) RED else CYAN)
        (bubbleView?.background as? GradientDrawable)?.setStroke(bubbleStroke(), if (rem <= 60) RED else CYAN)
        if (rem <= 0) { expire(); return }
        var hit = -1
        for (t in intArrayOf(60, 59, 10)) {
            if (rem <= t && fired.add(t)) hit = t
        }
        if (hit > 0 && !appForeground) warn(hit)
    }

    private fun warn(point: Int) {
        val muted = Prefs.muted(this)
        when (point) {
            60 -> {
                if (!muted) tone(ToneGenerator.TONE_PROP_BEEP2, 600)
                Notifs.post(this, 13, "One minute remaining", "Insert coin to add time")
            }
            59 -> if (!muted) speak("Warning. You have one minute remaining.")
            10 -> {
                if (!muted) { tone(ToneGenerator.TONE_CDMA_ABBR_ALERT, 500); speak("Please insert coin!") }
                Notifs.post(this, 14, "10 seconds remaining", "Please insert coin!")
            }
        }
    }

    private fun expire() {
        Prefs.setEndMs(this, 0L)
        handler.removeCallbacks(loop)
        // Time is up while the user is in another app: send the phone to its Home screen.
        // Done BEFORE removing the overlay window - a visible overlay is what lets Android
        // allow a start from the background.
        if (!appForeground) goToPhoneHome()
        removeOverlay()
        if (!appForeground) {
            if (!Prefs.muted(this)) tone(ToneGenerator.TONE_CDMA_ALERT_NETWORK_LITE, 1200)
            Notifs.post(this, 15, "Time expired", "Insert coin to start a new session")
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /** Same as pressing the Home button: the other app goes to the background. */
    private fun goToPhoneHome() {
        try {
            val home = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(home)
        } catch (_: Exception) {
            // Blocked by the system / phone brand: the "Time expired" notification still shows.
        }
    }

    private fun tone(type: Int, ms: Int) {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, Prefs.volume(this).coerceIn(1, 100))
            tg.startTone(type, ms)
            handler.postDelayed({ tg.release() }, ms + 300L)
        } catch (_: Exception) {}
    }

    private fun speak(text: String) {
        if (!ttsReady) return
        val b = Bundle()
        b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Prefs.volume(this) / 100f)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, b, "tg")
    }

    private fun fmt(sec: Int) = String.format(Locale.US, "%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)

    private fun bubbleStroke(): Int = (3 * resources.displayMetrics.density).toInt().coerceAtLeast(3)

    /** Small box (coin + time + X). X shrinks it to a circle; tapping the circle expands it again. */
    private fun createOverlay() {
        val d = resources.displayMetrics.density
        val s = Prefs.sizePct(this) / 100f
        fun dp(v: Float) = (v * d * s).toInt()

        val frame = FrameLayout(this)
        frame.alpha = Prefs.alphaPct(this) / 100f

        // ---- small box ----
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setPadding(dp(6f), dp(3f), dp(2f), dp(3f))
        box.background = GradientDrawable().apply {
            setColor(Color.argb(200, 4, 8, 20))
            cornerRadius = 10 * d * s
            setStroke((1.5f * d).toInt().coerceAtLeast(2), CYAN)
        }
        val coin = TextView(this)
        coin.text = "₱"
        coin.gravity = Gravity.CENTER
        coin.setTextColor(Color.rgb(90, 58, 0))
        coin.typeface = Typeface.DEFAULT_BOLD
        coin.textSize = 12f * s
        coin.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.rgb(255, 201, 51))
        }
        val cp = LinearLayout.LayoutParams(dp(22f), dp(22f))
        cp.rightMargin = dp(6f)
        box.addView(coin, cp)

        val tv = TextView(this)
        tv.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        tv.textSize = 17f * s
        tv.setTextColor(CYAN)
        tv.text = fmt(maxOf(remainingSec(), 0))
        box.addView(tv)

        val close = TextView(this)
        close.text = "✕"
        close.gravity = Gravity.CENTER
        close.setTextColor(Color.rgb(200, 215, 235))
        close.textSize = 14f * s
        close.setPadding(dp(10f), dp(4f), dp(8f), dp(4f))
        close.isClickable = true
        close.setOnClickListener { setCollapsed(true) }
        box.addView(close)

        // ---- circle ----
        val size = dp(44f)
        val bubble = TextView(this)
        bubble.text = "₱"
        bubble.gravity = Gravity.CENTER
        bubble.setTextColor(Color.rgb(90, 58, 0))
        bubble.typeface = Typeface.DEFAULT_BOLD
        bubble.textSize = 18f * s
        bubble.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.rgb(255, 201, 51))
            setStroke(bubbleStroke(), CYAN)
        }

        frame.addView(box)
        frame.addView(bubble, FrameLayout.LayoutParams(size, size))
        val collapsed = Prefs.collapsed(this)
        box.visibility = if (collapsed) View.GONE else View.VISIBLE
        bubble.visibility = if (collapsed) View.VISIBLE else View.GONE

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = Prefs.x(this)
        p.y = Prefs.y(this)

        attachDrag(box, p, frame, null)                       // drag the box
        attachDrag(bubble, p, frame) { setCollapsed(false) }  // drag the circle, tap = expand

        try {
            wm?.addView(frame, p)
            params = p
            root = frame
            boxView = box
            bubbleView = bubble
            timeView = tv
        } catch (_: Exception) {
            // Permission revoked between check and add: stay without overlay
        }
    }

    private fun setCollapsed(c: Boolean) {
        Prefs.setCollapsed(this, c)
        boxView?.visibility = if (c) View.GONE else View.VISIBLE
        bubbleView?.visibility = if (c) View.VISIBLE else View.GONE
        val r = root
        val p = params
        if (r != null && p != null) {
            try { wm?.updateViewLayout(r, p) } catch (_: Exception) {}
            handler.postDelayed({ keepOnScreen() }, 80)
        }
    }

    /** After box <-> circle the window size changes: never let it hang off the screen. */
    private fun keepOnScreen() {
        val r = root ?: return
        val p = params ?: return
        val dm = resources.displayMetrics
        p.x = p.x.coerceIn(0, maxOf(0, dm.widthPixels - r.width))
        p.y = p.y.coerceIn(0, maxOf(0, dm.heightPixels - r.height))
        try { wm?.updateViewLayout(r, p) } catch (_: Exception) {}
    }

    /** Drag with finger; a touch that barely moves counts as a tap. */
    private fun attachDrag(v: View, p: WindowManager.LayoutParams, frame: View, onTap: (() -> Unit)?) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        v.setOnTouchListener { _: View, e: MotionEvent ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                    if (moved) {
                        p.x = sx + dx
                        p.y = sy + dy
                        try { wm?.updateViewLayout(frame, p) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) Prefs.savePos(this, p.x, p.y) else onTap?.invoke()
                }
            }
            true
        }
    }

    private fun removeOverlay() {
        try { root?.let { wm?.removeView(it) } } catch (_: Exception) {}
        root = null
        params = null
        boxView = null
        bubbleView = null
        timeView = null
    }
}
